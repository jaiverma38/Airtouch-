import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.airtouchlocal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.airtouchlocal"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed signing key: every build is signed the same, so new versions
    // install over the old one without uninstalling (settings are kept).
    signingConfigs {
        getByName("debug") {
            storeFile = file("airtouch-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    // The .task model must not be compressed so MediaPipe can memory-map it.
    androidResources {
        noCompress += "task"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")

    // On-device hand tracking (runs fully offline once the model is bundled).
    implementation("com.google.mediapipe:tasks-vision:0.10.14")

}

// Downloads the hand-landmark model into assets at build time (needs internet
// only on the dev machine; the finished app never touches the network).
val modelFile = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
val downloadHandModel by tasks.registering {
    onlyIf { !modelFile.exists() || modelFile.length() < 1_000_000 }
    doLast {
        modelFile.parentFile.mkdirs()
        val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        println("Downloading hand_landmarker.task ...")
        URL(url).openStream().use { input ->
            modelFile.outputStream().use { out -> input.copyTo(out) }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadHandModel) }
