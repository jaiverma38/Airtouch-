import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.airtouchlocal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.airtouchlocal"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed signing key: every build is signed the same, so new versions
    // install over the old one without uninstalling (settings are kept).
    signingConfigs {
        getByName("debug") {
            storeFile = file("airtouch-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    // The .task model must not be compressed so MediaPipe can memory-map it.
    androidResources {
        noCompress += "task"
        noCompress += "zip"
    }

    // Vosk ships native libs (.so) for these CPUs only: keeps the APK smaller.
    defaultConfig {
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    packaging {
        jniLibs { pickFirsts += listOf("**/libc++_shared.so", "**/libjnidispatch.so") }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")

    // On-device hand tracking (runs fully offline once the model is bundled).
    implementation("com.google.mediapipe:tasks-vision:0.10.14")

    // Jarvis: offline speech recognition + speaker (voice owner) verification.
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    // Jarvis: encrypted storage + fingerprint/PIN gate.
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.biometric:biometric:1.1.0")
}

// Downloads the hand-landmark model into assets at build time (needs internet
// only on the dev machine; the finished app never touches the network).
val modelFile = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
val downloadHandModel by tasks.registering {
    onlyIf { !modelFile.exists() || modelFile.length() < 1_000_000 }
    doLast {
        modelFile.parentFile.mkdirs()
        val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        println("Downloading hand_landmarker.task ...")
        URL(url).openStream().use { input ->
            modelFile.outputStream().use { out -> input.copyTo(out) }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadHandModel) }

// Jarvis voice models (offline). Download is best-effort: if it fails here the
// app downloads them itself on first run, so the build never breaks because of it.
val voskDir = layout.projectDirectory.dir("src/main/assets/models").asFile
val voskModels = mapOf(
    "vosk-model-small-en-in-0.4.zip" to "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip",
    "vosk-model-spk-0.4.zip" to "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"
)
val downloadVoskModels by tasks.registering {
    doLast {
        voskDir.mkdirs()
        for ((name, url) in voskModels) {
            val target = File(voskDir, name)
            if (target.exists() && target.length() > 1_000_000) continue
            var ok = false
            for (attempt in 1..3) {
                try {
                    println("Downloading $name (try $attempt) ...")
                    val conn = URL(url).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 30_000
                    conn.readTimeout = 60_000
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    val tmp = File(voskDir, "$name.part")
                    conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
                    if (tmp.length() > 1_000_000) {
                        tmp.renameTo(target)
                        ok = true
                        break
                    }
                    tmp.delete()
                } catch (e: Exception) {
                    println("  failed: ${e.message}")
                }
            }
            if (!ok) println("WARNING: could not bundle $name; app will download it on first run.")
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadVoskModels) }
