package com.airtouchlocal

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var statusAccessibility: TextView
    private lateinit var statusTracking: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnPause: Button
    private lateinit var customContainer: LinearLayout
    private lateinit var builtinContainer: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startTracking() else toast("Camera permission ke bina tracking nahi chalegi")
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Notification is optional; continue either way.
            ensureCameraThenStart()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        GestureStore.load(this)

        statusAccessibility = findViewById(R.id.statusAccessibility)
        statusTracking = findViewById(R.id.statusTracking)
        btnToggle = findViewById(R.id.btnToggle)
        btnPause = findViewById(R.id.btnPause)
        customContainer = findViewById(R.id.customContainer)
        builtinContainer = findViewById(R.id.builtinContainer)

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Installed apps / Downloaded apps mein 'AirTouch Local' dhundho aur ON karo")
        }

        btnToggle.setOnClickListener {
            when {
                TrackingService.instance != null -> stopService(Intent(this, TrackingService::class.java))
                GestureAccessibilityService.instance == null -> {
                    toast("Pehle accessibility service enable karo")
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED ->
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                else -> ensureCameraThenStart()
            }
            handler.postDelayed({ refresh() }, 400)
        }

        btnPause.setOnClickListener {
            val svc = TrackingService.instance
            if (svc == null) {
                toast("Pehle tracking start karo")
            } else {
                svc.togglePause()
                handler.postDelayed({ refresh() }, 400)
            }
        }

        val seek = findViewById<SeekBar>(R.id.seekSpeed)
        seek.progress = Prefs.speed(this)
        seek.setOnSeekBarChangeListener(onProgress { Prefs.setSpeed(this, it) })

        val strict = findViewById<SeekBar>(R.id.seekStrict)
        strict.progress = Prefs.strictness(this)
        strict.setOnSeekBarChangeListener(onProgress { Prefs.setStrictness(this, it) })

        val invert = findViewById<CompoundButton>(R.id.switchInvert)
        invert.isChecked = Prefs.invertScroll(this)
        invert.setOnCheckedChangeListener { _, checked -> Prefs.setInvertScroll(this, checked) }

        val debugSwitch = findViewById<CompoundButton>(R.id.switchDebug)
        debugSwitch.isChecked = Prefs.debugMotion(this)
        debugSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setDebugMotion(this, checked) }

        findViewById<Button>(R.id.btnAddGesture).setOnClickListener { askName() }

        findViewById<Button>(R.id.btnResetBuiltins).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Built-in gestures default settings par wapas laayein?")
                .setPositiveButton("Haan") { _, _ ->
                    Prefs.resetBuiltins(this)
                    renderBuiltins()
                }
                .setNegativeButton("Nahi", null)
                .show()
        }

        renderGestures()
        renderBuiltins()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun onProgress(save: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            if (fromUser) save(p)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun ensureCameraThenStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startTracking()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startTracking() {
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
        handler.postDelayed({ refresh() }, 400)
    }

    private fun refresh() {
        val accOn = GestureAccessibilityService.instance != null
        val svc = TrackingService.instance
        val running = svc != null
        val paused = svc?.isPaused == true
        statusAccessibility.text =
            if (accOn) "✅ Accessibility service ON" else "⚠️ Accessibility service OFF"
        statusTracking.text = when {
            !running -> "⏹️ Tracking band hai"
            paused -> "⏸️ Tracking chal rahi hai, par AirTouch PAUSE hai"
            else -> "✅ Tracking chal rahi hai"
        }
        btnToggle.text = if (running) "Tracking stop karo" else "2. Tracking start karo"
        btnPause.text = if (paused) "AirTouch Resume" else "AirTouch Pause"
    }

    // ---------- custom gestures ----------

    private fun renderGestures() {
        customContainer.removeAllViews()
        val list = GestureStore.list
        if (list.isEmpty()) {
            customContainer.addView(TextView(this).apply { text = "Abhi koi custom gesture nahi hai." })
            return
        }
        for (g in list) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val actionLabel = ActionType.from(g.action)?.label ?: g.action
            val extra = if (g.action == ActionType.OPEN_APP.name) " (${appLabel(g.arg)})" else ""
            row.addView(
                TextView(this).apply {
                    val icon = if (g.kind == "motion") "👋" else "🖐️"
                    text = "$icon ${g.name}  →  $actionLabel$extra"
                    textSize = 15f
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "Hatao"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("'${g.name}' gesture hata dein?")
                        .setPositiveButton("Haan") { _, _ ->
                            GestureStore.remove(this@MainActivity, g.id)
                            renderGestures()
                        }
                        .setNegativeButton("Nahi", null)
                        .show()
                }
            })
            customContainer.addView(row)
        }
    }

    // ---------- built-in gestures ----------

    private val holdChoicesMs = longArrayOf(400, 600, 800, 1000, 1200, 1500, 2000, 3000)

    private fun renderBuiltins() {
        builtinContainer.removeAllViews()
        for (b in BuiltIn.values()) {
            val action = Prefs.builtinAction(this, b)
            val hold = Prefs.builtinHold(this, b)
            val extra = if (action == ActionType.OPEN_APP) " (${appLabel(Prefs.builtinArg(this, b))})" else ""
            val timing = if (action == ActionType.NONE) "" else "  [${hold / 1000f} sec]"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                TextView(this).apply {
                    text = "${b.label}$timing\n→ ${action.label}$extra"
                    textSize = 15f
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "Badlo"
                setOnClickListener { editBuiltin(b) }
            })
            builtinContainer.addView(row)
        }
    }

    private fun editBuiltin(b: BuiltIn) {
        val actions = ActionType.forBuiltin()
        AlertDialog.Builder(this)
            .setTitle("${b.label}: kya ho?")
            .setItems(actions.map { it.label }.toTypedArray()) { _, i ->
                val action = actions[i]
                when (action) {
                    ActionType.OPEN_APP -> pickApp { pkg -> askHold(b, action, pkg) }
                    ActionType.NONE -> saveBuiltin(b, action, null, Prefs.builtinHold(this, b))
                    else -> askHold(b, action, null)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHold(b: BuiltIn, action: ActionType, arg: String?) {
        val labels = holdChoicesMs.map { "${it / 1000f} sec" }.toTypedArray()
        val current = holdChoicesMs.indexOfFirst { it == Prefs.builtinHold(this, b) }
        AlertDialog.Builder(this)
            .setTitle("Kitni der pakdna hai?")
            .setSingleChoiceItems(labels, current) { dialog, i ->
                dialog.dismiss()
                saveBuiltin(b, action, arg, holdChoicesMs[i])
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveBuiltin(b: BuiltIn, action: ActionType, arg: String?, holdMs: Long) {
        Prefs.setBuiltin(this, b, action, arg, holdMs)
        renderBuiltins()
        if (b == BuiltIn.THREE && action != ActionType.TOGGLE_PAUSE) {
            toast("Dhyan rakho: ab pause se resume karne ke liye app ya notification ka Resume button use karna.")
        }
    }

    private fun appLabel(pkg: String?): String {
        if (pkg == null) return "?"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }
    }

    private fun askName() {
        if (TrackingService.instance == null) {
            toast("Gesture record karne ke liye pehle Tracking start karo")
            return
        }
        val input = EditText(this).apply { hint = "Gesture ka naam (jaise Thumbs up)" }
        AlertDialog.Builder(this)
            .setTitle("Naya gesture")
            .setView(input)
            .setPositiveButton("Aage") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) toast("Naam likho") else askKind(name)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askKind(name: String) {
        val kinds = arrayOf(
            "✋ Pose: haath ki shape banao aur pakde rakho (thumbs-up, rock sign...)",
            "👋 Movement: haath hilao (swipe left/right/up/down, circle, wave...)"
        )
        AlertDialog.Builder(this)
            .setTitle("Gesture kaisa hai?")
            .setItems(kinds) { _, i -> askAction(name, if (i == 1) "motion" else "pose") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askAction(name: String, kind: String) {
        val actions = ActionType.forCustom()
        AlertDialog.Builder(this)
            .setTitle("Is gesture se kya ho?")
            .setItems(actions.map { it.label }.toTypedArray()) { _, i ->
                val action = actions[i]
                if (action == ActionType.OPEN_APP) {
                    pickApp { pkg -> startRecord(name, kind, action, pkg) }
                } else {
                    startRecord(name, kind, action, null)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startRecord(name: String, kind: String, action: ActionType, arg: String?) {
        if (kind == "motion") recordMotion(name, action, arg) else recordPose(name, action, arg)
    }

    private fun pickApp(onPicked: (String) -> Unit) {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        AlertDialog.Builder(this)
            .setTitle("Kaun sa app khole?")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i ->
                onPicked(apps[i].second)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun recordPose(name: String, action: ActionType, arg: String?) {
        val svc = TrackingService.instance
        if (svc == null) {
            toast("Tracking band hai. Pehle start karo.")
            return
        }
        var cancelled = false
        var countdown = 3
        val dialog = AlertDialog.Builder(this)
            .setTitle("'$name' record ho raha hai")
            .setMessage("Haath front camera ke saamne laao aur pose banao...")
            .setCancelable(false)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
        // Dialog at the bottom, no dimming, so the live hand preview at the top stays visible.
        dialog.window?.let { w ->
            w.setDimAmount(0f)
            w.setGravity(Gravity.BOTTOM)
        }
        svc.setCapture(true)

        lateinit var tick: Runnable
        tick = Runnable {
            if (cancelled) return@Runnable
            if (countdown > 0) {
                dialog.setMessage("Pose banao, $countdown...")
                countdown--
                handler.postDelayed(tick, 1000)
            } else {
                dialog.setMessage("Pose pakdo, haath hilao mat...")
                svc.beginRecording { template, error ->
                    runOnUiThread {
                        if (!cancelled) {
                            dialog.dismiss()
                            handleRecorded(name, action, arg, template, error)
                        }
                    }
                }
            }
        }
        dialog.setOnDismissListener {
            cancelled = true
            handler.removeCallbacks(tick)
            TrackingService.instance?.setCapture(false)
        }
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
            cancelled = true
            handler.removeCallbacks(tick)
            svc.cancelRecording()
            dialog.dismiss()
        }
        handler.post(tick)
    }

    private fun recordMotion(name: String, action: ActionType, arg: String?) {
        val svc = TrackingService.instance
        if (svc == null) {
            toast("Tracking band hai. Pehle start karo.")
            return
        }
        var cancelled = false
        var countdown = 3
        val dialog = AlertDialog.Builder(this)
            .setTitle("'$name' (movement) record ho raha hai")
            .setMessage("Haath front camera ke saamne laao...")
            .setCancelable(false)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
        dialog.window?.let { w ->
            w.setDimAmount(0f)
            w.setGravity(Gravity.BOTTOM)
        }
        svc.setCapture(true)

        lateinit var tick: Runnable
        tick = Runnable {
            if (cancelled) return@Runnable
            if (countdown > 0) {
                dialog.setMessage("Haath ready rakho (khula panja ya mutthi), $countdown...")
                countdown--
                handler.postDelayed(tick, 1000)
            } else {
                dialog.setMessage("Ab haath hilao (swipe / circle), phir ruk jao!")
                svc.beginMotionRecording { path, poseName, error ->
                    runOnUiThread {
                        if (!cancelled) {
                            dialog.dismiss()
                            handleMotionRecorded(name, action, arg, path, poseName, error)
                        }
                    }
                }
            }
        }
        dialog.setOnDismissListener {
            cancelled = true
            handler.removeCallbacks(tick)
            TrackingService.instance?.setCapture(false)
        }
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
            cancelled = true
            handler.removeCallbacks(tick)
            svc.cancelRecording()
            dialog.dismiss()
        }
        handler.post(tick)
    }

    private fun handleMotionRecorded(
        name: String,
        action: ActionType,
        arg: String?,
        path: FloatArray?,
        poseName: String?,
        error: String?
    ) {
        if (path == null || poseName == null) {
            toast(error ?: "Record nahi ho paya")
            return
        }
        val clash = GestureStore.list.firstOrNull {
            it.kind == "motion" && MotionTracker.distance(it.template, path) < 0.35f
        }
        if (clash != null) {
            toast("Ye movement '${clash.name}' jaisa hi hai. Alag movement chuno.")
            return
        }
        GestureStore.add(
            this,
            CustomGesture(UUID.randomUUID().toString(), name, action.name, arg, path, "motion", poseName)
        )
        renderGestures()
        toast("'$name' save ho gaya. Wahi haath ki shape rakhke wahi movement karo to action chalega.")
    }

    private fun handleRecorded(
        name: String,
        action: ActionType,
        arg: String?,
        template: FloatArray?,
        error: String?
    ) {
        if (template == null) {
            toast(error ?: "Record nahi ho paya")
            return
        }
        val n = template.size / 2
        val xs = FloatArray(n) { template[2 * it] }
        val ys = FloatArray(n) { template[2 * it + 1] }
        val pose = Features.classify(xs, ys)
        if (pose == Pose.POINT || pose == Pose.SCROLL) {
            toast("Ye pose cursor/scroll wale built-in gesture jaisa hai. Koi alag pose chuno (thumbs-up, rock sign, OK sign...).")
            return
        }
        val clash = GestureStore.list.firstOrNull {
            it.kind == "pose" && Features.distance(it.template, template) < 0.18f
        }
        if (clash != null) {
            toast("Ye pose '${clash.name}' jaisa hi hai. Alag pose chuno.")
            return
        }
        GestureStore.add(
            this,
            CustomGesture(UUID.randomUUID().toString(), name, action.name, arg, template)
        )
        renderGestures()
        toast("'$name' save ho gaya. Ab ye pose 0.7 sec pakdo to action chalega.")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
