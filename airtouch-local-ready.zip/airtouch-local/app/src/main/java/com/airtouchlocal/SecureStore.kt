package com.airtouchlocal

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** One enrolled (trusted) voice. [vec] is the L2-normalised speaker x-vector. */
data class VoiceProfile(val name: String, val vec: FloatArray)

/**
 * Everything private lives here, encrypted with a key held in the Android Keystore:
 * voice prints, API key, settings, intruder log.
 */
object SecureStore {
    private const val FILE = "jarvis_secure"

    @Volatile private var cached: SharedPreferences? = null
    @Volatile var encrypted = true
        private set

    private fun sp(c: Context): SharedPreferences {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val app = c.applicationContext
            val made = try {
                val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
                EncryptedSharedPreferences.create(
                    app, FILE, key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (_: Throwable) {
                encrypted = false
                app.getSharedPreferences(FILE + "_plain", Context.MODE_PRIVATE)
            }
            cached = made
            return made
        }
    }

    // ---- voice profiles ----

    fun profiles(c: Context): List<VoiceProfile> {
        val raw = sp(c).getString("voices", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val v = o.getJSONArray("v")
                VoiceProfile(o.getString("n"), FloatArray(v.length()) { k -> v.getDouble(k).toFloat() })
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun saveProfiles(c: Context, list: List<VoiceProfile>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("n", p.name)
            val v = JSONArray()
            for (f in p.vec) v.put(f.toDouble())
            o.put("v", v)
            arr.put(o)
        }
        sp(c).edit().putString("voices", arr.toString()).apply()
    }

    fun addProfile(c: Context, p: VoiceProfile) {
        saveProfiles(c, profiles(c).filter { it.name != p.name } + p)
    }

    fun removeProfile(c: Context, name: String) {
        saveProfiles(c, profiles(c).filter { it.name != name })
    }

    fun hasVoice(c: Context): Boolean = profiles(c).isNotEmpty()

    // ---- settings ----

    /** Max cosine distance accepted as "same speaker" (lower = stricter). */
    fun threshold(c: Context): Float = sp(c).getFloat("thr", 0.55f)
    fun setThreshold(c: Context, v: Float) = sp(c).edit().putFloat("thr", v).apply()

    fun showDistance(c: Context): Boolean = sp(c).getBoolean("showDist", false)
    fun setShowDistance(c: Context, v: Boolean) = sp(c).edit().putBoolean("showDist", v).apply()

    fun speak(c: Context): Boolean = sp(c).getBoolean("speak", true)
    fun setSpeak(c: Context, v: Boolean) = sp(c).edit().putBoolean("speak", v).apply()

    fun onlineEnabled(c: Context): Boolean = sp(c).getBoolean("online", false)
    fun setOnlineEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("online", v).apply()

    fun apiKey(c: Context): String = sp(c).getString("apikey", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("apikey", v.trim()).apply()

    fun apiModel(c: Context): String = sp(c).getString("apimodel", "claude-haiku-5-5") ?: "claude-haiku-5-5"
    fun setApiModel(c: Context, v: String) = sp(c).edit().putString("apimodel", v.trim()).apply()

    // ---- intruder log ----

    fun logIntruder(c: Context, distance: Float) {
        val s = sp(c)
        val n = s.getInt("intr_n", 0) + 1
        s.edit().putInt("intr_n", n).putLong("intr_last", System.currentTimeMillis())
            .putFloat("intr_dist", distance).apply()
    }

    fun intruderCount(c: Context): Int = sp(c).getInt("intr_n", 0)
    fun intruderLast(c: Context): Long = sp(c).getLong("intr_last", 0L)
    fun clearIntruders(c: Context) = sp(c).edit().remove("intr_n").remove("intr_last").remove("intr_dist").apply()
}
