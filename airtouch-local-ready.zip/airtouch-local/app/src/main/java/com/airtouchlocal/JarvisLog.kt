package com.airtouchlocal

import android.os.Handler
import android.os.Looper

/** Tiny in-memory log shown on the Jarvis screen (never written to disk). */
object JarvisLog {
    private val lines = ArrayDeque<String>()
    private val main = Handler(Looper.getMainLooper())

    @Volatile var listener: ((String) -> Unit)? = null
    @Volatile var statusListener: ((String) -> Unit)? = null

    @Synchronized
    fun add(line: String) {
        lines.addLast(line)
        while (lines.size > 12) lines.removeFirst()
        val text = lines.joinToString("\n")
        main.post { listener?.invoke(text) }
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    fun status(s: String) {
        main.post { statusListener?.invoke(s) }
    }
}
