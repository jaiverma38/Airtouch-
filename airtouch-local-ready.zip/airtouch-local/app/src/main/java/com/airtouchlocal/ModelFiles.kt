package com.airtouchlocal

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Prepares the offline Vosk models: unpack from the APK if bundled, otherwise
 * download once from the Vosk site (the only time the app fetches a model).
 */
object ModelFiles {
    const val ASR = "vosk-model-small-en-in-0.4"
    const val SPK = "vosk-model-spk-0.4"
    private const val BASE = "https://alphacephei.com/vosk/models/"

    fun dir(c: Context, name: String) = File(File(c.filesDir, "models"), name)

    fun ready(c: Context): Boolean = File(dir(c, ASR), ".ok").exists() && File(dir(c, SPK), ".ok").exists()

    /** Blocking. Call from a background thread. Throws on failure. */
    fun ensure(c: Context, status: (String) -> Unit) {
        for (name in listOf(ASR, SPK)) {
            val d = dir(c, name)
            if (File(d, ".ok").exists()) continue
            d.deleteRecursively()
            d.mkdirs()
            val assetName = "models/$name.zip"
            val bundled = try { c.assets.open(assetName).close(); true } catch (_: Throwable) { false }
            if (bundled) {
                status("Model taiyar ho raha hai: $name")
                c.assets.open(assetName).use { unzip(it, d) }
            } else {
                status("Model download ho raha hai: $name (internet chahiye, ek baar)")
                val tmp = File(c.cacheDir, "$name.zip")
                download(BASE + "$name.zip", tmp) { pct -> status("Download $name: $pct%") }
                status("Model taiyar ho raha hai: $name")
                tmp.inputStream().use { unzip(it, d) }
                tmp.delete()
            }
            File(d, ".ok").writeText("ok")
        }
    }

    private fun download(url: String, to: File, progress: (Int) -> Unit) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        val total = conn.contentLengthLong
        var done = 0L
        var lastPct = -1
        conn.inputStream.use { input ->
            to.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct && pct % 5 == 0) { lastPct = pct; progress(pct) }
                    }
                }
            }
        }
        if (to.length() < 1_000_000) throw IllegalStateException("download incomplete")
    }

    /** Extracts a Vosk zip into [dest], dropping the single top-level folder. Blocks zip-slip. */
    private fun unzip(input: java.io.InputStream, dest: File) {
        val root = dest.canonicalPath + File.separator
        ZipInputStream(input.buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val out = File(dest, rel)
                if (!out.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
            }
        }
    }
}
