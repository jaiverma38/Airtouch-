package com.airtouchlocal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service: front camera -> MediaPipe hand landmarks -> GestureEngine.
 * Everything happens on this phone; the app has no INTERNET permission.
 */
class TrackingService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.airtouchlocal.STOP"
        const val ACTION_TOGGLE = "com.airtouchlocal.TOGGLE_PAUSE"
        private const val CHANNEL_ID = "tracking"
        private const val NOTIF_ID = 1
        private const val PAUSED_FRAME_GAP_MS = 150L

        @Volatile
        var instance: TrackingService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var executor: ExecutorService
    private var tracker: HandTracker? = null
    @Volatile private var engine: GestureEngine? = null
    private var analysis: ImageAnalysis? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var started = false

    @Volatile private var aspect = 0.75f
    @Volatile private var lastFrameMs = 0L

    val isPaused: Boolean get() = engine?.paused == true

    fun togglePause() {
        engine?.togglePause()
    }

    /** Records the pose currently shown to the camera; [onDone] runs on a background thread. */
    fun beginRecording(onDone: (FloatArray?, String?) -> Unit) {
        val e = engine
        if (e == null) onDone(null, "Tracking chal nahi rahi") else e.startRecording(SystemClock.uptimeMillis(), onDone)
    }

    /** While on, the screen shows a live hand skeleton and no gestures are executed. */
    fun setCapture(on: Boolean) {
        engine?.setCapture(on)
    }

    fun cancelRecording() {
        engine?.cancelRecording()
        engine?.cancelMotionRecording()
    }

    /** Records one hand movement; [onDone] gets (path, poseName, error) on a background thread. */
    fun beginMotionRecording(onDone: (FloatArray?, String?, String?) -> Unit) {
        val e = engine
        if (e == null) onDone(null, null, "Tracking chal nahi rahi")
        else e.startMotionRecording(SystemClock.uptimeMillis(), onDone)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        executor = Executors.newSingleThreadExecutor()
        createChannel()
        val notification = buildNotification(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                togglePause()
                return START_NOT_STICKY
            }
        }
        if (!started) {
            started = true
            startPipeline()
        }
        return START_NOT_STICKY
    }

    private fun startPipeline() {
        val a11y = GestureAccessibilityService.instance
        if (a11y == null) {
            toast("Pehle Accessibility service enable karo")
            stopSelf()
            return
        }

        GestureStore.load(applicationContext)

        val settings = object : GestureEngine.Settings {
            override val speed: Int get() = Prefs.speed(applicationContext)
            override val invertScroll: Boolean get() = Prefs.invertScroll(applicationContext)
            override val strictness: Int get() = Prefs.strictness(applicationContext)
            override val gestures: List<CustomGesture> get() = GestureStore.list
            override val debug: Boolean get() = Prefs.debugMotion(applicationContext)
            override fun actionFor(b: BuiltIn): ActionType = Prefs.builtinAction(applicationContext, b)
            override fun argFor(b: BuiltIn): String? = Prefs.builtinArg(applicationContext, b)
            override fun holdMs(b: BuiltIn): Long = Prefs.builtinHold(applicationContext, b)
        }

        // Same as the accessibility service, but also refreshes the notification on pause/resume.
        val sink = object : GestureEngine.Sink by a11y {
            override fun onPausedChanged(paused: Boolean) {
                a11y.onPausedChanged(paused)
                main.post { updateNotification(paused) }
            }
        }

        val eng = GestureEngine(sink, settings)
        engine = eng

        try {
            tracker = HandTracker(
                applicationContext,
                onResult = { xs, ys, ts -> eng.process(xs, ys, ts, aspect) },
                onError = { msg -> toast(msg) }
            )
        } catch (t: Throwable) {
            toast("Hand model load nahi hua (hand_landmarker.task assets mein hai?): ${t.message}")
            stopSelf()
            return
        }

        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider

                val useCase = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(640, 480),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                                )
                            ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetRotation(GestureAccessibilityService.instance?.currentRotation ?: Surface.ROTATION_0)
                    .build()

                useCase.setAnalyzer(executor) { proxy ->
                    try {
                        val now = SystemClock.uptimeMillis()
                        // While paused, only sample a few frames per second to save battery.
                        val eng2 = engine
                        if (eng2 != null && eng2.paused && !eng2.captureMode &&
                            now - lastFrameMs < PAUSED_FRAME_GAP_MS
                        ) {
                            // skip this frame
                        } else {
                            lastFrameMs = now
                            val src = proxy.toBitmap()
                            val m = Matrix().apply {
                                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                                postScale(-1f, 1f)   // mirror: moving right moves the cursor right
                            }
                            val upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
                            aspect = upright.width.toFloat() / upright.height.toFloat()
                            tracker?.detect(upright, now)
                        }
                    } catch (_: Throwable) {
                        // drop frame
                    } finally {
                        proxy.close()
                    }
                }
                analysis = useCase

                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, useCase)
            } catch (t: Throwable) {
                toast("Camera start nahi hua: ${t.message}")
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    fun updateRotation(rotation: Int) {
        analysis?.targetRotation = rotation
    }

    override fun onDestroy() {
        instance = null
        try { cameraProvider?.unbindAll() } catch (_: Throwable) {}
        tracker?.close()
        tracker = null
        engine = null
        executor.shutdown()
        GestureAccessibilityService.instance?.onHandLost()
        super.onDestroy()
    }

    // ---------- notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gesture tracking", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun updateNotification(paused: Boolean) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(paused))
        } catch (_: Throwable) {}
    }

    private fun buildNotification(paused: Boolean): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TrackingService::class.java).setAction(ACTION_STOP), flags
        )
        val toggle = PendingIntent.getService(
            this, 2, Intent(this, TrackingService::class.java).setAction(ACTION_TOGGLE), flags
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), flags)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(if (paused) "AirTouch Local: PAUSE" else "AirTouch Local chal raha hai")
            .setContentText("Camera frames sirf is phone par process hote hain")
            .setContentIntent(open)
            .addAction(0, if (paused) "Resume" else "Pause", toggle)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }
}
