package com.airtouchlocal

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Executes a parsed [Cmd]. Returns the sentence Jarvis should say. Must be called on the main thread. */
object JarvisActions {

    private fun a11y(): GestureAccessibilityService? = GestureAccessibilityService.instance

    private fun needA11y(): String = "Pehle AirTouch me accessibility service enable karo."

    private fun launch(c: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        true
    } catch (_: Throwable) {
        false
    }

    private fun global(action: ActionType): String? {
        val svc = a11y() ?: return needA11y()
        svc.onAction(action, null, svc.screenWidth / 2f, svc.screenHeight / 2f)
        return null
    }

    fun run(c: Context, cmd: Cmd): String {
        return try {
            exec(c.applicationContext, cmd)
        } catch (e: Throwable) {
            "Ye kaam nahi ho paya."
        }
    }

    private fun exec(c: Context, cmd: Cmd): String {
        when (cmd.kind) {
            Kind.HELLO -> return "Haan boliye, main Jarvis hu. Hukum kijiye."
            Kind.BACK -> return global(ActionType.BACK) ?: "Peeche."
            Kind.HOME -> return global(ActionType.HOME) ?: "Home."
            Kind.RECENTS -> return global(ActionType.RECENTS) ?: "Recent apps."
            Kind.NOTIFICATIONS -> return global(ActionType.NOTIFICATIONS) ?: "Notifications."
            Kind.QUICK_SETTINGS -> return global(ActionType.QUICK_SETTINGS) ?: "Quick settings."
            Kind.LOCK -> return global(ActionType.LOCK_SCREEN) ?: "Phone lock kar diya."
            Kind.SCREENSHOT -> return global(ActionType.SCREENSHOT) ?: "Screenshot le liya."
            Kind.SCROLL_DOWN -> return global(ActionType.SCROLL_DOWN) ?: ""
            Kind.SCROLL_UP -> return global(ActionType.SCROLL_UP) ?: ""

            Kind.VOL_UP -> {
                audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                return "Volume badha diya."
            }
            Kind.VOL_DOWN -> {
                audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                return "Volume kam kar diya."
            }
            Kind.MUTE -> {
                audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                return "Mute."
            }
            Kind.PLAY_PAUSE -> { media(c, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return "Theek hai." }
            Kind.NEXT -> { media(c, KeyEvent.KEYCODE_MEDIA_NEXT); return "Agla gaana." }
            Kind.PREV -> { media(c, KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Pichla gaana." }

            Kind.TORCH_ON, Kind.TORCH_OFF -> {
                val on = cmd.kind == Kind.TORCH_ON
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { id ->
                    val ch = cm.getCameraCharacteristics(id)
                    ch.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        ch.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING) ==
                        android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
                } ?: return "Is phone me torch nahi mili."
                cm.setTorchMode(id, on)
                return if (on) "Torch on." else "Torch off."
            }

            Kind.WIFI -> {
                launch(c, Intent(Settings.ACTION_WIFI_SETTINGS))
                return "Wifi settings khol di. Android ab app ko wifi seedha on/off nahi karne deta."
            }
            Kind.BLUETOOTH -> {
                launch(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                return "Bluetooth settings khol di."
            }
            Kind.SETTINGS -> { launch(c, Intent(Settings.ACTION_SETTINGS)); return "Settings." }
            Kind.CAMERA -> {
                return if (launch(c, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) "Camera khol diya." else "Camera nahi khul paya."
            }

            Kind.TIME -> return "Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " baje hain."
            Kind.DATE -> return "Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()) + " hai."
            Kind.BATTERY -> {
                val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                return "Battery $pct percent hai."
            }

            Kind.TIMER -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, cmd.num)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (launch(c, i)) "Timer laga diya." else "Timer nahi laga paya."
            }
            Kind.ALARM -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, cmd.num)
                    .putExtra(AlarmClock.EXTRA_MINUTES, cmd.num2)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (launch(c, i)) "Alarm set kar diya." else "Alarm nahi lag paya."
            }

            Kind.SEARCH -> {
                val q = cmd.arg
                val uri = if (q.startsWith("youtube:"))
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q.removePrefix("youtube:")))
                else
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
                return if (launch(c, Intent(Intent.ACTION_VIEW, uri))) "Search kar raha hu." else "Browser nahi mila."
            }

            Kind.CALL -> return call(c, cmd.arg)
            Kind.OPEN_APP -> return openApp(c, cmd.arg)

            Kind.AIRTOUCH_ON -> {
                if (TrackingService.instance != null) {
                    val t = TrackingService.instance!!
                    if (t.isPaused) t.togglePause()
                    return "AirTouch chalu hai."
                }
                if (ContextCompat.checkSelfPermission(c, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                    return "Camera permission pehle app me do."
                if (a11y() == null) return needA11y()
                ContextCompat.startForegroundService(c, Intent(c, TrackingService::class.java))
                return "AirTouch start kar diya."
            }
            Kind.AIRTOUCH_OFF -> {
                val t = TrackingService.instance ?: return "AirTouch pehle se band hai."
                t.stopSelf()
                return "AirTouch band kar diya."
            }

            Kind.SECURITY_CHECK -> {
                val r = SecurityAudit.run(c)
                return r.spoken
            }

            Kind.SLEEP, Kind.SHUTDOWN, Kind.UNKNOWN -> return ""
        }
        @Suppress("UNREACHABLE_CODE")
        return ""
    }

    private fun audio(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun media(c: Context, code: Int) {
        val am = audio(c)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun openApp(c: Context, name: String): String {
        val pm = c.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val want = norm(name)
        if (want.isEmpty()) return "Kaunsa app?"
        var best: String? = null
        var bestLabel = ""
        var bestScore = Int.MAX_VALUE
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val l = norm(label)
            if (l.isEmpty()) continue
            val score = when {
                l == want -> 0
                l.startsWith(want) || want.startsWith(l) -> 1
                l.contains(want) || want.contains(l) -> 2
                else -> Int.MAX_VALUE
            }
            if (score < bestScore) {
                bestScore = score
                best = ri.activityInfo.packageName
                bestLabel = label
            }
        }
        if (best == null) return "$name naam ka app nahi mila."
        val li = pm.getLaunchIntentForPackage(best) ?: return "$bestLabel nahi khul paya."
        return if (launch(c, li)) "$bestLabel khol raha hu." else "$bestLabel nahi khul paya."
    }

    private fun call(c: Context, who: String): String {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.length >= 5) {
            launch(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
            return "Number dial screen par daal diya, call button dabao."
        }
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Contacts ka permission nahi hai. Jarvis screen me Contacts allow karo."
        }
        val q = norm(who)
        var number: String? = null
        var found = ""
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        )?.use { cur ->
            var bestScore = Int.MAX_VALUE
            while (cur.moveToNext()) {
                val n = cur.getString(0) ?: continue
                val ln = norm(n)
                val score = when {
                    ln == q -> 0
                    ln.startsWith(q) -> 1
                    ln.contains(q) -> 2
                    else -> Int.MAX_VALUE
                }
                if (score < bestScore) {
                    bestScore = score
                    number = cur.getString(1)
                    found = n
                }
            }
        }
        val num = number ?: return "$who naam ka contact nahi mila."
        launch(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
        return "$found ka number dial screen par hai, call button dabao."
    }
}
