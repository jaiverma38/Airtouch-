package com.airtouchlocal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Path
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Draws the air-cursor overlay and performs taps / swipes / global actions.
 * Receives actions from [GestureEngine] (which runs on the camera thread),
 * so everything touching UI or gestures is posted to the main thread.
 */
class GestureAccessibilityService : AccessibilityService(), GestureEngine.Sink {

    companion object {
        @Volatile
        var instance: GestureAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var cursorView: CursorView? = null

    @Volatile override var screenWidth = 0
    @Volatile override var screenHeight = 0

    val currentRotation: Int
        @Suppress("DEPRECATION")
        get() = (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        updateMetrics()
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }

    override fun onInterrupt() { /* not used */ }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateMetrics()
        TrackingService.instance?.updateRotation(currentRotation)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeOverlay()
        TrackingService.instance?.stopSelf()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeOverlay()
        super.onDestroy()
    }

    // ---------- overlay ----------

    @Suppress("DEPRECATION")
    private fun updateMetrics() {
        val dm = DisplayMetrics()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        screenWidth = dm.widthPixels
        screenHeight = dm.heightPixels
    }

    private fun addOverlay() {
        if (cursorView != null) return
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = CursorView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        manager.addView(view, lp)
        wm = manager
        cursorView = view
    }

    private fun removeOverlay() {
        cursorView?.let { v -> try { wm?.removeView(v) } catch (_: Throwable) {} }
        cursorView = null
    }

    // ---------- GestureEngine.Sink ----------

    override fun onCursor(x: Float, y: Float, pressed: Boolean) {
        main.post { cursorView?.update(x, y, pressed) }
    }

    override fun onHandLost() {
        main.post { cursorView?.hide() }
    }

    override fun onTap(x: Float, y: Float) {
        main.post { stroke(x, y, x, y, 50) }
    }

    override fun onLongPress(x: Float, y: Float) {
        main.post { stroke(x, y, x, y, 700) }
    }

    override fun onScroll(swipeUp: Boolean) {
        main.post { swipeVertical(swipeUp) }
    }

    override fun onBack() {
        main.post { performGlobalAction(GLOBAL_ACTION_BACK) }
    }

    override fun onHome() {
        main.post { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    override fun onPausedChanged(paused: Boolean) {
        main.post {
            buzz(longArrayOf(0, 60, 90, 60))
            Toast.makeText(
                applicationContext,
                if (paused) "AirTouch PAUSE ⏸️ (3 ungliyan 1.2 sec se resume)" else "AirTouch ACTIVE ▶️",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onCustomAction(gesture: CustomGesture, cursorX: Float, cursorY: Float) {
        main.post {
            buzz(longArrayOf(0, 50))
            runAction(gesture, cursorX, cursorY)
        }
    }

    // ---------- actions ----------

    private fun runAction(g: CustomGesture, x: Float, y: Float) {
        val action = ActionType.from(g.action) ?: return
        try {
            when (action) {
                ActionType.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
                ActionType.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
                ActionType.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                ActionType.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                ActionType.QUICK_SETTINGS -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                ActionType.LOCK_SCREEN ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                ActionType.SCREENSHOT ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                ActionType.TAP -> stroke(x, y, x, y, 50)
                ActionType.SCROLL_DOWN -> swipeVertical(true)    // swipe up = see content below
                ActionType.SCROLL_UP -> swipeVertical(false)
                ActionType.VOLUME_UP -> adjustVolume(AudioManager.ADJUST_RAISE)
                ActionType.VOLUME_DOWN -> adjustVolume(AudioManager.ADJUST_LOWER)
                ActionType.PLAY_PAUSE -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                ActionType.OPEN_APP -> openApp(g.arg)
                ActionType.TOGGLE_PAUSE -> { /* handled inside the engine */ }
            }
        } catch (_: Throwable) {
            // never crash the service because of one action
        }
    }

    private fun openApp(pkg: String?) {
        if (pkg == null) return
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun adjustVolume(direction: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun sendMediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun swipeVertical(swipeUp: Boolean) {
        val x = screenWidth / 2f
        val a = screenHeight * 0.68f
        val b = screenHeight * 0.32f
        if (swipeUp) stroke(x, a, x, b, 260) else stroke(x, b, x, a, 260)
    }

    private fun stroke(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    @Suppress("DEPRECATION")
    private fun buzz(pattern: LongArray) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            v.vibrate(pattern, -1)
        }
    }
}
