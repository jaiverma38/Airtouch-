package com.airtouchlocal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional online mode. Only used when the user enabled it AND stored an API key.
 * Only the TEXT of an already voice-verified command is sent (never audio or camera).
 * The model can only pick from a fixed list of actions; anything else is ignored.
 */
object OnlineBrain {

    data class Answer(val cmd: Cmd?, val say: String)

    private const val SYSTEM = """You are Jarvis, a voice assistant inside an Android phone app. The owner speaks Hindi, English or Hinglish.
Reply with ONLY one JSON object, no other text:
{"action": "<ACTION>", "arg": "<string or empty>", "num": <integer or 0>, "say": "<short reply in the owner's language, max 25 words>"}
Allowed ACTION values: NONE, BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, SCREENSHOT, SCROLL_DOWN, SCROLL_UP, VOL_UP, VOL_DOWN, MUTE, PLAY_PAUSE, NEXT, PREV, OPEN_APP (arg = app name), CALL (arg = contact name or digits), SEARCH (arg = query), TORCH_ON, TORCH_OFF, WIFI, BLUETOOTH, SETTINGS, CAMERA, TIME, DATE, BATTERY, TIMER (num = seconds), SECURITY_CHECK.
Use NONE for questions or chat and put the answer in "say". Never invent other actions."""

    fun available(c: Context): Boolean =
        SecureStore.onlineEnabled(c) && SecureStore.apiKey(c).isNotEmpty()

    /** Blocking network call; run off the main thread. Returns null on any failure. */
    fun ask(c: Context, text: String): Answer? {
        if (!available(c)) return null
        return try {
            val body = JSONObject()
                .put("model", SecureStore.apiModel(c))
                .put("max_tokens", 300)
                .put("system", SYSTEM)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 25_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", SecureStore.apiKey(c))
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) return null
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val out = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            parse(out)
        } catch (_: Throwable) {
            null
        }
    }

    private fun parse(raw: String): Answer? {
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val o = JSONObject(raw.substring(a, b + 1))
        val say = o.optString("say", "")
        val name = o.optString("action", "NONE").uppercase()
        val kind = try { Kind.valueOf(name) } catch (_: Throwable) { null }
        val allowed = setOf(
            Kind.BACK, Kind.HOME, Kind.RECENTS, Kind.NOTIFICATIONS, Kind.QUICK_SETTINGS, Kind.LOCK,
            Kind.SCREENSHOT, Kind.SCROLL_DOWN, Kind.SCROLL_UP, Kind.VOL_UP, Kind.VOL_DOWN, Kind.MUTE,
            Kind.PLAY_PAUSE, Kind.NEXT, Kind.PREV, Kind.OPEN_APP, Kind.CALL, Kind.SEARCH, Kind.TORCH_ON,
            Kind.TORCH_OFF, Kind.WIFI, Kind.BLUETOOTH, Kind.SETTINGS, Kind.CAMERA, Kind.TIME, Kind.DATE,
            Kind.BATTERY, Kind.TIMER, Kind.SECURITY_CHECK
        )
        val cmd = if (kind != null && kind in allowed)
            Cmd(kind, arg = o.optString("arg", ""), num = o.optInt("num", 0))
        else null
        return Answer(cmd, say)
    }
}
