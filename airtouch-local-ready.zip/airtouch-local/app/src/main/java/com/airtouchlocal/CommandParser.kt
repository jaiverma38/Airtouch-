package com.airtouchlocal

enum class Kind {
    UNKNOWN, HELLO, BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, SCREENSHOT,
    SCROLL_DOWN, SCROLL_UP, VOL_UP, VOL_DOWN, MUTE, PLAY_PAUSE, NEXT, PREV,
    OPEN_APP, CALL, SEARCH, TORCH_ON, TORCH_OFF, WIFI, BLUETOOTH, SETTINGS, CAMERA,
    TIME, DATE, BATTERY, TIMER, ALARM, AIRTOUCH_ON, AIRTOUCH_OFF, SECURITY_CHECK,
    SLEEP, SHUTDOWN
}

data class Cmd(val kind: Kind, val arg: String = "", val num: Int = 0, val num2: Int = 0)

/** Rule-based English / Hinglish / Hindi command understanding. Fully offline. */
object CommandParser {

    const val WAKE = "jarvis"

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    fun tokenize(text: String): List<String> =
        text.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }

    private fun isWakeToken(t: String): Boolean =
        t == "जार्विस" || t == "जारविस" || t == "जर्विस" || (t.length >= 5 && lev(t, WAKE) <= 2)

    /** Returns null if no wake word, else the tokens after it. */
    fun stripWake(tokens: List<String>): List<String>? {
        val limit = minOf(tokens.size, 4)
        for (i in 0 until limit) {
            if (isWakeToken(tokens[i])) return tokens.drop(i + 1)
            if (i + 1 < tokens.size && (tokens[i] + tokens[i + 1]).let { isWakeToken(it) }) {
                return tokens.drop(i + 2)
            }
        }
        return null
    }

    private val units = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19, "ek" to 1, "char" to 4,
        "paanch" to 5, "panch" to 5, "chhe" to 6, "saat" to 7, "aath" to 8, "nau" to 9, "das" to 10,
        "barah" to 12, "pandrah" to 15, "bees" to 20, "tees" to 30, "chalis" to 40, "pachas" to 50
    )
    private val tens = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60,
        "seventy" to 70, "eighty" to 80, "ninety" to 90
    )
    private val digitWords = mapOf(
        "zero" to '0', "oh" to '0', "one" to '1', "two" to '2', "three" to '3', "four" to '4',
        "five" to '5', "six" to '6', "seven" to '7', "eight" to '8', "nine" to '9'
    )

    /** First number found in tokens (digits or words like "twenty five"), or -1. */
    private fun firstNumber(tokens: List<String>): Int {
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            t.toIntOrNull()?.let { return it }
            if (tens.containsKey(t)) {
                var v = tens[t]!!
                val nxt = tokens.getOrNull(i + 1)
                if (nxt != null && units[nxt] != null && units[nxt]!! in 1..9) v += units[nxt]!!
                return v
            }
            units[t]?.let { return it }
            i++
        }
        return -1
    }

    private fun allNumbers(tokens: List<String>): List<Int> {
        val out = ArrayList<Int>()
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val n = t.toIntOrNull()
            if (n != null) { out.add(n); i++; continue }
            if (tens.containsKey(t)) {
                var v = tens[t]!!
                val nxt = tokens.getOrNull(i + 1)
                if (nxt != null && units[nxt] != null && units[nxt]!! in 1..9) { v += units[nxt]!!; i++ }
                out.add(v); i++; continue
            }
            if (units.containsKey(t)) { out.add(units[t]!!) }
            i++
        }
        return out
    }

    /** Phone number spoken digit by digit ("nine eight seven ..."), or "". */
    private fun spokenDigits(tokens: List<String>): String {
        val sb = StringBuilder()
        for (t in tokens) {
            if (t.all { it.isDigit() }) sb.append(t)
            else digitWords[t]?.let { sb.append(it) }
        }
        return if (sb.length >= 5) sb.toString() else ""
    }

    private val FILLER = setOf(
        "karo", "kar", "do", "de", "dena", "please", "plz", "the", "a", "an", "app", "ko", "ka", "ki",
        "ke", "mera", "mere", "meri", "my", "to", "for", "me", "mein", "se", "aur", "zara", "jara",
        "ab", "abhi", "now", "can", "you", "could", "will", "kya", "tum", "aap", "hai", "ho", "na",
        "bhai", "yaar", "sir", "kijiye", "kijiye", "dijiye", "krdo", "kro", "krna", "karna", "on"
    )

    private fun has(t: Set<String>, vararg words: String) = words.any { it in t }
    private fun hasPhrase(s: String, vararg ps: String) = ps.any { s.contains(it) }

    fun parse(rawTokens: List<String>): Cmd {
        val tokens = rawTokens
        if (tokens.isEmpty()) return Cmd(Kind.UNKNOWN)
        val set = tokens.toSet()
        val s = tokens.joinToString(" ")

        // --- control of Jarvis itself ---
        if (hasPhrase(s, "shutdown", "shut down", "exit jarvis", "band ho ja", "jarvis band", "jarvis off", "turn off jarvis", "quit")) {
            return Cmd(Kind.SHUTDOWN)
        }
        if (hasPhrase(s, "so ja", "so jao", "sleep", "stop listening", "chup ho", "chup raho", "standby", "ruk jao", "ruko")) {
            return Cmd(Kind.SLEEP)
        }

        // --- security ---
        if (has(set, "security", "suraksha", "audit", "scan") ||
            hasPhrase(s, "phone safe", "phone secure", "virus check", "secure hai", "safe hai")
        ) return Cmd(Kind.SECURITY_CHECK)

        // --- AirTouch (hand gestures) ---
        if (has(set, "airtouch", "gesture", "gestures") || hasPhrase(s, "air touch", "hand control")) {
            val off = has(set, "off", "stop", "band", "pause", "disable", "rok")
            return Cmd(if (off) Kind.AIRTOUCH_OFF else Kind.AIRTOUCH_ON)
        }

        // --- timer / alarm ---
        if (has(set, "timer")) {
            val n = firstNumber(tokens)
            if (n > 0) {
                val secs = when {
                    has(set, "second", "seconds", "sec", "secs", "sekand") -> n
                    has(set, "hour", "hours", "ghanta", "ghante", "ghanta") -> n * 3600
                    else -> n * 60
                }
                return Cmd(Kind.TIMER, num = secs)
            }
        }
        if (has(set, "alarm")) {
            val nums = allNumbers(tokens)
            if (nums.isNotEmpty()) {
                var h = nums[0]
                val m = if (nums.size > 1) nums[1] else 0
                val pm = has(set, "pm", "shaam", "raat", "evening", "night", "dopahar", "afternoon")
                val am = has(set, "am", "subah", "morning", "savere")
                if (pm && h in 1..11) h += 12
                if (am && h == 12) h = 0
                if (h in 0..23 && m in 0..59) return Cmd(Kind.ALARM, num = h, num2 = m)
            }
        }

        // --- information ---
        if (hasPhrase(s, "kitne baje", "what time", "kya time", "samay", "time kya", "current time") || (has(set, "time") && tokens.size <= 3)) {
            return Cmd(Kind.TIME)
        }
        if (has(set, "date", "tarikh", "tareekh", "aaj") && !has(set, "open", "kholo")) return Cmd(Kind.DATE)
        if (has(set, "battery", "charge", "charging")) return Cmd(Kind.BATTERY)

        // --- device toggles ---
        if (has(set, "torch", "flashlight", "flash", "torch") || hasPhrase(s, "flash light")) {
            val off = has(set, "off", "band", "bujha", "bujhao", "stop")
            return Cmd(if (off) Kind.TORCH_OFF else Kind.TORCH_ON)
        }
        if (has(set, "wifi", "wi", "internet")) return Cmd(Kind.WIFI)
        if (has(set, "bluetooth", "blutooth")) return Cmd(Kind.BLUETOOTH)
        if (has(set, "settings", "setting")) {
            if (has(set, "quick", "control")) return Cmd(Kind.QUICK_SETTINGS)
            return Cmd(Kind.SETTINGS)
        }
        if (has(set, "camera")) return Cmd(Kind.CAMERA)

        // --- volume / media ---
        if (has(set, "volume", "awaaz", "awaz", "sound")) {
            if (has(set, "mute", "zero", "silent", "band", "off")) return Cmd(Kind.MUTE)
            if (has(set, "down", "kam", "ghatao", "ghata", "decrease", "lower", "low", "dheere", "reduce")) return Cmd(Kind.VOL_DOWN)
            return Cmd(Kind.VOL_UP)
        }
        if (has(set, "mute", "silent", "chup")) return Cmd(Kind.MUTE)
        if (has(set, "next", "agla", "agle", "skip")) return Cmd(Kind.NEXT)
        if (has(set, "previous", "pichla", "pichle", "prev")) return Cmd(Kind.PREV)
        if (has(set, "pause", "resume", "rok", "roko") || (has(set, "play") && !has(set, "store")) ||
            hasPhrase(s, "music chalao", "gaana chalao", "gana chalao", "music band", "gaana band")
        ) return Cmd(Kind.PLAY_PAUSE)

        // --- navigation ---
        if (has(set, "screenshot") || hasPhrase(s, "screen shot", "capture screen")) return Cmd(Kind.SCREENSHOT)
        if (has(set, "lock") || hasPhrase(s, "screen band", "screen off", "phone band", "lock kar")) return Cmd(Kind.LOCK)
        if (has(set, "notification", "notifications")) return Cmd(Kind.NOTIFICATIONS)
        if (has(set, "recent", "recents", "multitask") || hasPhrase(s, "recent apps")) return Cmd(Kind.RECENTS)
        if (has(set, "scroll", "swipe") || has(set, "neeche", "niche", "upar", "oopar", "ooper")) {
            val up = has(set, "up", "upar", "oopar", "ooper")
            return Cmd(if (up) Kind.SCROLL_UP else Kind.SCROLL_DOWN)
        }

        // --- search / call before generic "open" ---
        val searchWords = setOf("search", "google", "dhundo", "dhoondo", "dhundh", "youtube")
        if (tokens.any { it in searchWords }) {
            val q = tokens.filter { it !in searchWords && it !in FILLER }.joinToString(" ")
            if (q.isNotBlank()) return Cmd(Kind.SEARCH, arg = if ("youtube" in set) "youtube:$q" else q)
        }
        val callWords = setOf("call", "dial", "phone", "lagao", "ring")
        if (tokens.any { it in callWords } && !has(set, "lock", "band")) {
            val digits = spokenDigits(tokens)
            if (digits.isNotEmpty()) return Cmd(Kind.CALL, arg = digits)
            val who = tokens.filter { it !in callWords && it !in FILLER && it != "lagao" }.joinToString(" ")
            if (who.isNotBlank()) return Cmd(Kind.CALL, arg = who)
        }

        // --- open app ---
        val openWords = setOf("open", "launch", "start", "kholo", "khol", "chalao", "chalu", "run", "kholna")
        if (tokens.any { it in openWords }) {
            val name = tokens.filter { it !in openWords && it !in FILLER }.joinToString(" ")
            if (name.isNotBlank()) return Cmd(Kind.OPEN_APP, arg = name)
        }

        // --- back / home (short phrases, last, since the words are common) ---
        if (has(set, "back", "peeche", "piche", "wapas", "vapas")) return Cmd(Kind.BACK)
        if (has(set, "home", "ghar")) return Cmd(Kind.HOME)

        if (has(set, "hello", "hi", "hey", "namaste", "kaun", "who") || hasPhrase(s, "kaise ho", "how are you")) {
            return Cmd(Kind.HELLO)
        }
        return Cmd(Kind.UNKNOWN, arg = s)
    }
}
