package com.airtouchlocal

import kotlin.math.hypot
import kotlin.math.max

/**
 * Detects "a movement of the hand" (swipe, circle, wave...) from the palm-centre path.
 *
 * Feed it one palm position per camera frame. When the hand starts moving fast it begins
 * collecting points; when the hand slows down again it returns a [Result] with the path
 * resampled to [N] points, measured in "hand sizes" (so it works at any distance) and
 * starting at the origin. Direction matters: swipe-left and swipe-right are different.
 */
class MotionTracker {

    class Result(val path: FloatArray, val pose: Pose, val durationMs: Long)

    companion object {
        const val N = 32
        private const val START_SPEED = 1.5f      // hand sizes per second
        private const val STOP_SPEED = 0.6f
        private const val STOP_HOLD_MS = 250L
        private const val MAX_MS = 2500L
        private const val MIN_MS = 200L
        private const val MIN_LEN_HS = 1.0f
        private const val ABORT_POINT_FRAMES = 3

        /** Centre of the palm in the same units as [hand size]. */
        fun centerX(gx: FloatArray): Float = (gx[0] + gx[5] + gx[9] + gx[13] + gx[17]) / 5f
        fun centerY(ys: FloatArray): Float = (ys[0] + ys[5] + ys[9] + ys[13] + ys[17]) / 5f

        fun pathLength(p: FloatArray): Float {
            var total = 0f
            var i = 2
            while (i + 1 < p.size) {
                total += hypot(p[i] - p[i - 2], p[i + 1] - p[i - 1])
                i += 2
            }
            return total
        }

        /** Mean distance between corresponding points of two resampled paths. */
        fun distance(a: FloatArray, b: FloatArray): Float {
            val n = minOf(a.size, b.size) / 2
            if (n == 0) return Float.MAX_VALUE
            var sum = 0f
            for (k in 0 until n) sum += hypot(a[2 * k] - b[2 * k], a[2 * k + 1] - b[2 * k + 1])
            return sum / n
        }

        private fun resample(xs: List<Float>, ys: List<Float>, n: Int): FloatArray {
            val m = xs.size
            val out = FloatArray(n * 2)
            if (m < 2) return out
            val cum = FloatArray(m)
            for (i in 1 until m) cum[i] = cum[i - 1] + hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1])
            val total = cum[m - 1]
            if (total < 1e-6f) return out
            val step = total / (n - 1)
            var seg = 1
            for (j in 0 until n) {
                val t = j * step
                while (seg < m - 1 && cum[seg] < t) seg++
                val segLen = cum[seg] - cum[seg - 1]
                val f = if (segLen > 1e-9f) ((t - cum[seg - 1]) / segLen).coerceIn(0f, 1f) else 0f
                out[2 * j] = xs[seg - 1] + (xs[seg] - xs[seg - 1]) * f
                out[2 * j + 1] = ys[seg - 1] + (ys[seg] - ys[seg - 1]) * f
            }
            return out
        }
    }

    private val px = ArrayList<Float>()
    private val py = ArrayList<Float>()
    private val votes = IntArray(Pose.values().size)
    private var collecting = false
    private var hasPrev = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var speed = 0f
    private var startT = 0L
    private var slowSince = 0L
    private var sizeSum = 0f
    private var sizeN = 0
    private var pointFrames = 0

    val isCollecting: Boolean get() = collecting

    fun reset() {
        collecting = false
        hasPrev = false
        speed = 0f
        slowSince = 0L
        pointFrames = 0
        px.clear(); py.clear()
        votes.fill(0)
        sizeSum = 0f; sizeN = 0
    }

    /**
     * @param handSize wrist-to-middle-knuckle distance in the same units as [cx]/[cy]
     * @return a finished movement, or null
     */
    fun feed(cx: Float, cy: Float, handSize: Float, pose: Pose, now: Long): Result? {
        val hs = max(handSize, 1e-4f)
        if (!hasPrev) {
            hasPrev = true
            lastX = cx; lastY = cy; lastT = now
            return null
        }
        val dtSec = max(now - lastT, 1L) / 1000f
        val inst = hypot(cx - lastX, cy - lastY) / hs / dtSec
        speed = 0.5f * speed + 0.5f * inst
        val prevX = lastX
        val prevY = lastY
        lastX = cx; lastY = cy; lastT = now

        val pointing = pose == Pose.POINT || pose == Pose.SCROLL

        if (!collecting) {
            if (speed > START_SPEED && !pointing) {
                collecting = true
                startT = now
                slowSince = 0L
                pointFrames = 0
                px.clear(); py.clear()
                votes.fill(0)
                sizeSum = 0f; sizeN = 0
                px.add(prevX); py.add(prevY)
                px.add(cx); py.add(cy)
                votes[pose.ordinal]++
                sizeSum += hs; sizeN++
            }
            return null
        }

        // collecting
        if (pointing) {
            if (++pointFrames >= ABORT_POINT_FRAMES) {   // user went back to cursor mode
                collecting = false
                return null
            }
        } else {
            pointFrames = 0
        }
        px.add(cx); py.add(cy)
        votes[pose.ordinal]++
        sizeSum += hs; sizeN++

        if (speed < STOP_SPEED) {
            if (slowSince == 0L) slowSince = now
            if (now - slowSince >= STOP_HOLD_MS) return finish(now)
        } else {
            slowSince = 0L
        }
        if (now - startT > MAX_MS) return finish(now)
        return null
    }

    private fun finish(now: Long): Result? {
        collecting = false
        val duration = now - startT
        val avgHs = max(sizeSum / max(sizeN, 1), 1e-4f)
        val x0 = px[0]
        val y0 = py[0]
        val nx = px.map { (it - x0) / avgHs }
        val ny = py.map { (it - y0) / avgHs }
        val path = resample(nx, ny, N)
        if (duration < MIN_MS || pathLength(path) < MIN_LEN_HS) return null

        var best = 0
        for (i in votes.indices) {
            if (i == Pose.POINT.ordinal || i == Pose.SCROLL.ordinal || i == Pose.NONE.ordinal) continue
            if (votes[i] > votes[best]) best = i
        }
        if (votes[best] == 0) return null
        return Result(path, Pose.values()[best], duration)
    }
}
