package com.airtouchlocal

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker

/**
 * Thin wrapper around MediaPipe HandLandmarker (LIVE_STREAM mode).
 * The model file is bundled in assets, so inference is fully offline.
 * [onResult] gets x/y arrays (21 each) or nulls when no hand is visible.
 */
class HandTracker(
    context: Context,
    private val onResult: (xs: FloatArray?, ys: FloatArray?, timestampMs: Long) -> Unit,
    private val onError: (String) -> Unit
) {
    private val landmarker: HandLandmarker
    private var lastTs = 0L

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, _ ->
                val hands = result.landmarks()
                val ts = result.timestampMs()
                if (hands.isEmpty()) {
                    onResult(null, null, ts)
                } else {
                    val lm = hands[0]
                    val xs = FloatArray(lm.size) { lm[it].x() }
                    val ys = FloatArray(lm.size) { lm[it].y() }
                    onResult(xs, ys, ts)
                }
            }
            .setErrorListener { e -> onError(e.message ?: "Hand tracker error") }
            .build()

        landmarker = HandLandmarker.createFromOptions(context, options)
    }

    /** [bitmap] must already be upright (and mirrored for the front camera). */
    fun detect(bitmap: Bitmap, timestampMs: Long) {
        var ts = timestampMs
        if (ts <= lastTs) ts = lastTs + 1   // MediaPipe needs strictly increasing timestamps
        lastTs = ts
        landmarker.detectAsync(BitmapImageBuilder(bitmap).build(), ts)
    }

    fun close() {
        try { landmarker.close() } catch (_: Throwable) {}
    }
}
