package com.airtouchlocal

import android.content.Context

/** Built-in gestures whose action and hold time the user can change. */
enum class BuiltIn(
    val key: String,
    val label: String,
    val defAction: ActionType,
    val defHoldMs: Long
) {
    FIST("fist", "✊ Mutthi (hold)", ActionType.BACK, 1000L),
    PALM("palm", "🖐️ Khula panja (hold)", ActionType.HOME, 1500L),
    THREE("three", "🤟 Teen ungliyan (hold)", ActionType.TOGGLE_PAUSE, 1200L),
    PINCH_HOLD("pinch", "🤏 Pinch pakdo", ActionType.LONG_PRESS, 600L),
    TWO_UP("two_up", "✌️ Do ungliyan, haath UPAR karo", ActionType.SCROLL_MODE, 0L),
    TWO_DOWN("two_down", "✌️ Do ungliyan, haath NEECHE karo", ActionType.SCROLL_MODE, 0L)
}

/** Tiny local settings store (SharedPreferences, stays on the phone). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("airtouch", Context.MODE_PRIVATE)

    fun speed(c: Context): Int = sp(c).getInt("speed", 45)
    fun setSpeed(c: Context, v: Int) = sp(c).edit().putInt("speed", v).apply()

    fun invertScroll(c: Context): Boolean = sp(c).getBoolean("invert", false)
    fun setInvertScroll(c: Context, v: Boolean) = sp(c).edit().putBoolean("invert", v).apply()

    fun builtinAction(c: Context, b: BuiltIn): ActionType =
        ActionType.from(sp(c).getString("b_${b.key}_action", b.defAction.name) ?: "") ?: b.defAction

    fun builtinArg(c: Context, b: BuiltIn): String? = sp(c).getString("b_${b.key}_arg", null)

    fun builtinHold(c: Context, b: BuiltIn): Long = sp(c).getLong("b_${b.key}_hold", b.defHoldMs)

    fun setBuiltin(c: Context, b: BuiltIn, action: ActionType, arg: String?, holdMs: Long) {
        sp(c).edit()
            .putString("b_${b.key}_action", action.name)
            .putString("b_${b.key}_arg", arg)
            .putLong("b_${b.key}_hold", holdMs)
            .apply()
    }

    fun resetBuiltins(c: Context) {
        val e = sp(c).edit()
        for (b in BuiltIn.values()) {
            e.remove("b_${b.key}_action").remove("b_${b.key}_arg").remove("b_${b.key}_hold")
        }
        e.apply()
    }

    fun debugMotion(c: Context): Boolean = sp(c).getBoolean("debug_motion", false)
    fun setDebugMotion(c: Context, v: Boolean) = sp(c).edit().putBoolean("debug_motion", v).apply()

    /** 0 = loose, 100 = strict matching of custom gestures. */
    fun strictness(c: Context): Int = sp(c).getInt("strict", 50)
    fun setStrictness(c: Context, v: Int) = sp(c).edit().putInt("strict", v).apply()
}
