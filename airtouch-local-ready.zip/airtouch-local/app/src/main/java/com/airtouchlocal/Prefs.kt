package com.airtouchlocal

import android.content.Context

/** Tiny local settings store (SharedPreferences, stays on the phone). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("airtouch", Context.MODE_PRIVATE)

    fun speed(c: Context): Int = sp(c).getInt("speed", 45)
    fun setSpeed(c: Context, v: Int) = sp(c).edit().putInt("speed", v).apply()

    fun invertScroll(c: Context): Boolean = sp(c).getBoolean("invert", false)
    fun setInvertScroll(c: Context, v: Boolean) = sp(c).edit().putBoolean("invert", v).apply()

    /** 0 = loose, 100 = strict matching of custom gestures. */
    fun strictness(c: Context): Int = sp(c).getInt("strict", 50)
    fun setStrictness(c: Context, v: Int) = sp(c).edit().putInt("strict", v).apply()
}
