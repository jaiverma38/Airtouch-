package com.airtouchlocal

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

class JarvisActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var voiceBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var secView: TextView
    private lateinit var intruderView: TextView
    private var pending: (() -> Unit)? = null
    @Volatile private var enrolling = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (ok) pending?.invoke() else toast("Microphone permission zaruri hai")
            pending = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            toast(if (ok) "Contacts allow ho gaye" else "Contacts allow nahi hue")
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        buildUi()
        root.visibility = View.INVISIBLE
        authenticate()
    }

    override fun onResume() {
        super.onResume()
        JarvisLog.listener = { t -> logView.text = t }
        JarvisLog.statusListener = { s -> statusView.text = s }
        logView.text = JarvisLog.text()
        refresh()
    }

    override fun onPause() {
        JarvisLog.listener = null
        JarvisLog.statusListener = null
        super.onPause()
    }

    // ---------- fingerprint / PIN gate ----------

    private fun authenticate() {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val can = BiometricManager.from(this).canAuthenticate(auth)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            toast("Phone me screen lock/fingerprint nahi hai: Jarvis screen unlocked hai. Pehle screen lock lagao.")
            root.visibility = View.VISIBLE
            return
        }
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    root.visibility = View.VISIBLE
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    toast("Unlock nahi hua: $errString")
                    finish()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Jarvis unlock")
            .setSubtitle("Fingerprint ya screen lock se confirm karo")
            .setAllowedAuthenticators(auth)
            .build()
        prompt.authenticate(info)
    }

    // ---------- UI ----------

    private fun label(text: String, size: Float = 14f, bold: Boolean = false, top: Int = 12): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(top), 0, dp(2))
        }

    private fun button(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit): SwitchCompat =
        SwitchCompat(this).apply {
            this.text = text
            isChecked = checked
            setPadding(0, dp(6), 0, dp(6))
            setOnCheckedChangeListener { _, b -> onChange(b) }
        }

    private fun buildUi() {
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)

        root.addView(label("Jarvis", 28f, true, 0))
        root.addView(label("Sirf owner ki awaaz se chalne wala offline voice assistant. Awaaz aur camera phone se bahar nahi jaate."))

        statusView = label("Band hai", 16f, true)
        root.addView(statusView)

        startBtn = button("Jarvis start karo") { toggleService() }
        root.addView(startBtn)

        // ---- voice lock ----
        root.addView(label("Owner ki awaaz (voice lock)", 20f, true, 24))
        root.addView(label("Jarvis sirf enrolled awaaz par kaam karta hai. Shant jagah me 3 baar 5 sec bolo (kuch bhi, jaise \"Jarvis, mera phone sirf mere hukum se chalega\")."))
        voiceBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(voiceBox)
        root.addView(button("+ Awaaz enroll karo (owner add karo)") { askEnroll() })

        root.addView(label("Voice matching: dheela ↔ sakht", 14f, true, 16))
        val seek = SeekBar(this).apply {
            max = 100
            // threshold 0.90 (loose) .. 0.30 (strict)
            progress = ((0.90f - SecureStore.threshold(this@JarvisActivity)) / 0.60f * 100f).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) SecureStore.setThreshold(this@JarvisActivity, 0.90f - 0.60f * p / 100f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek)
        root.addView(label("Agar aap ki awaaz reject ho to dheela karo; agar koi aur chal jaye to sakht karo. \"Voice distance dikhao\" ON karke test karo."))
        root.addView(switchRow("Voice distance dikhao (tuning ke liye)", SecureStore.showDistance(this)) {
            SecureStore.setShowDistance(this, it)
        })

        intruderView = label("")
        root.addView(intruderView)
        root.addView(button("Anjaan-awaaz counter reset") {
            SecureStore.clearIntruders(this)
            refresh()
        })

        // ---- general ----
        root.addView(label("Settings", 20f, true, 24))
        root.addView(switchRow("Jarvis bol kar jawab de", SecureStore.speak(this)) { SecureStore.setSpeak(this, it) })
        root.addView(button("Contacts allow karo (naam se call ke liye)") {
            contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
        })

        // ---- online ----
        root.addView(label("Online mode (optional)", 20f, true, 24))
        root.addView(label("Default OFF. ON karne par jo command offline samajh me na aaye, uska TEXT (awaaz nahi) Anthropic API ko jata hai, aur Jarvis sawaalon ke jawab bhi de sakta hai. Aap ki apni API key lagti hai (console.anthropic.com), jo encrypted store me rehti hai."))
        val keyEdit = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(if (SecureStore.apiKey(this@JarvisActivity).isNotEmpty()) "••••••••" else "")
        }
        root.addView(keyEdit)
        val modelEdit = EditText(this).apply {
            hint = "Model"
            setText(SecureStore.apiModel(this@JarvisActivity))
        }
        root.addView(modelEdit)
        root.addView(button("Key / model save karo") {
            val k = keyEdit.text.toString().trim()
            if (k.isNotEmpty() && !k.startsWith("•")) SecureStore.setApiKey(this, k)
            val m = modelEdit.text.toString().trim()
            if (m.isNotEmpty()) SecureStore.setApiModel(this, m)
            keyEdit.setText(if (SecureStore.apiKey(this).isNotEmpty()) "••••••••" else "")
            toast("Save ho gaya")
        })
        root.addView(switchRow("Online mode ON", SecureStore.onlineEnabled(this)) {
            SecureStore.setOnlineEnabled(this, it)
            if (it && SecureStore.apiKey(this).isEmpty()) toast("Pehle API key save karo")
        })

        // ---- security ----
        root.addView(label("Phone security check", 20f, true, 24))
        root.addView(button("Security scan chalao") {
            secView.text = SecurityAudit.run(this).fullText()
        })
        secView = label("")
        root.addView(secView)

        // ---- log ----
        root.addView(label("Live log", 20f, true, 24))
        logView = label("", 13f)
        logView.setTextIsSelectable(false)
        root.addView(logView)

        root.addView(label("Commands ke example", 20f, true, 24))
        root.addView(label(
            "Jarvis, back / home / recents / screenshot / lock kar do\n" +
            "Jarvis, YouTube kholo   |   Jarvis, open WhatsApp\n" +
            "Jarvis, volume badhao / kam karo / mute\n" +
            "Jarvis, torch on / off\n" +
            "Jarvis, call Mummy  |  Jarvis, call 9 8 7 6 5 4 3 2 1 0\n" +
            "Jarvis, set timer for five minutes\n" +
            "Jarvis, set alarm seven thirty am\n" +
            "Jarvis, battery kitni hai / time kya hua\n" +
            "Jarvis, search cricket score\n" +
            "Jarvis, airtouch on / off\n" +
            "Jarvis, security check\n" +
            "Jarvis, so jao   |   Jarvis, shutdown", 14f
        ))
    }

    // ---------- state ----------

    private fun refresh() {
        startBtn.text = if (JarvisService.running) "Jarvis band karo" else "Jarvis start karo"
        if (!enrolling) {
            statusView.text = when {
                JarvisService.running -> "Sun raha hu: bolo \"Jarvis ...\""
                !SecureStore.hasVoice(this) -> "Pehle apni awaaz enroll karo"
                else -> "Band hai"
            }
        }
        voiceBox.removeAllViews()
        val profiles = SecureStore.profiles(this)
        if (profiles.isEmpty()) {
            voiceBox.addView(label("Koi awaaz enroll nahi hai."))
        }
        for (p in profiles) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = "🎙 " + p.name
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "Hatao"
                isAllCaps = false
                setOnClickListener {
                    AlertDialog.Builder(this@JarvisActivity)
                        .setMessage("${p.name} ki awaaz hatani hai?")
                        .setPositiveButton("Haan") { _, _ ->
                            SecureStore.removeProfile(this@JarvisActivity, p.name)
                            if (!SecureStore.hasVoice(this@JarvisActivity)) JarvisService.stop(this@JarvisActivity)
                            refresh()
                        }
                        .setNegativeButton("Nahi", null)
                        .show()
                }
            })
            voiceBox.addView(row)
        }
        val n = SecureStore.intruderCount(this)
        intruderView.text = if (n == 0) "Anjaan awaaz se koi command nahi aayi."
        else "Anjaan awaaz block hui: $n baar (last: " +
            DateFormat.getDateTimeInstance().format(Date(SecureStore.intruderLast(this))) + ")"
        if (!SecureStore.encrypted) {
            intruderView.append("\n⚠ Is phone par encrypted store nahi bana, normal private storage use ho raha hai.")
        }
    }

    private fun needAudio(then: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            then()
            return
        }
        pending = then
        val perms = ArrayList<String>()
        perms.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun toggleService() {
        if (JarvisService.running) {
            JarvisService.stop(this)
            JarvisService.running = false
            refresh()
            return
        }
        if (!SecureStore.hasVoice(this)) {
            toast("Pehle apni awaaz enroll karo")
            return
        }
        needAudio {
            JarvisService.start(this)
            statusView.text = "Start ho raha hai..."
            startBtn.text = "Jarvis band karo"
        }
    }

    // ---------- enrollment ----------

    private fun askEnroll() {
        if (enrolling) return
        val input = EditText(this).apply {
            hint = "Naam (jaise Mera / Papa)"
            setText(if (SecureStore.hasVoice(this@JarvisActivity)) "" else "Owner")
        }
        AlertDialog.Builder(this)
            .setTitle("Kiski awaaz?")
            .setView(input)
            .setPositiveButton("Shuru") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "Owner" }
                needAudio { startEnroll(name) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startEnroll(name: String) {
        if (enrolling) return
        enrolling = true
        if (JarvisService.running) {
            JarvisService.stop(this)
            JarvisService.running = false
        }
        val prompts = listOf(
            "Bolo: \"Jarvis, mera phone sirf mere hukum se chalega\"",
            "Bolo: \"Jarvis, abhi time kya hua hai aur battery kitni hai\"",
            "Bolo: \"Jarvis, YouTube kholo aur volume thoda badha do\""
        )
        Thread {
            try {
                if (!ModelFiles.ready(this)) {
                    ModelFiles.ensure(this) { s -> runOnUiThread { statusView.text = s } }
                }
                runOnUiThread { statusView.text = "Awaaz engine load ho raha hai..." }
                val vecs = ArrayList<FloatArray>()
                VoiceEnroller(this).use { en ->
                    for ((i, p) in prompts.withIndex()) {
                        runOnUiThread { statusView.text = "Sample ${i + 1}/3 (5 sec)\n$p" }
                        Thread.sleep(900)
                        val v = en.record(5) { left ->
                            runOnUiThread { statusView.text = "Sample ${i + 1}/3: $left sec baaki\n$p" }
                        }
                        if (v == null) {
                            runOnUiThread { toast("Awaaz kam aayi, dobara try karo") }
                            return@Thread
                        }
                        vecs.add(v)
                    }
                }
                val avg = VoiceMath.average(vecs)
                SecureStore.addProfile(this, VoiceProfile(name, avg))
                runOnUiThread { toast("$name ki awaaz save ho gayi") }
            } catch (e: Throwable) {
                runOnUiThread { toast("Enroll fail: " + (e.message ?: e.javaClass.simpleName)) }
            } finally {
                enrolling = false
                runOnUiThread { refresh() }
            }
        }.start()
    }
}
