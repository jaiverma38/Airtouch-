package com.airtouchlocal

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import kotlin.math.sqrt

object VoiceMath {
    fun normalize(v: FloatArray): FloatArray {
        var s = 0.0
        for (x in v) s += x * x
        val n = sqrt(s).toFloat()
        return if (n == 0f) v else FloatArray(v.size) { v[it] / n }
    }

    fun cosineDistance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return 2f
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na == 0.0 || nb == 0.0) return 2f
        return (1.0 - dot / (sqrt(na) * sqrt(nb))).toFloat()
    }

    fun average(vs: List<FloatArray>): FloatArray {
        val out = FloatArray(vs[0].size)
        for (v in vs) for (i in out.indices) out[i] += v[i]
        val cnt = vs.size.toFloat()
        for (i in out.indices) out[i] = out[i] / cnt
        return normalize(out)
    }

    fun parse(arr: org.json.JSONArray?): FloatArray? {
        if (arr == null || arr.length() == 0) return null
        return FloatArray(arr.length()) { arr.getDouble(it).toFloat() }
    }
}

/** Records short samples of the owner's voice and turns them into speaker x-vectors. */
class VoiceEnroller(c: Context) : AutoCloseable {
    private val model = Model(ModelFiles.dir(c, ModelFiles.ASR).absolutePath)
    private val spk = SpeakerModel(ModelFiles.dir(c, ModelFiles.SPK).absolutePath)

    /** Blocking. Records [seconds] seconds; returns a normalised vector or null if too little speech. */
    fun record(seconds: Int, onSecond: (Int) -> Unit): FloatArray? {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, rate * 2)
        )
        if (ar.state != AudioRecord.STATE_INITIALIZED) {
            ar.release()
            return null
        }
        val rec = Recognizer(model, rate.toFloat(), spk)
        try {
            ar.startRecording()
            val buf = ShortArray(2048)
            var total = 0
            var lastSec = -1
            while (total < rate * seconds) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) continue
                rec.acceptWaveForm(buf, n)
                total += n
                val sec = total / rate
                if (sec != lastSec) { lastSec = sec; onSecond(seconds - sec) }
            }
            val j = JSONObject(rec.finalResult)
            val v = VoiceMath.parse(j.optJSONArray("spk")) ?: return null
            return VoiceMath.normalize(v)
        } finally {
            try { ar.stop() } catch (_: Throwable) {}
            ar.release()
            rec.close()
        }
    }

    override fun close() {
        spk.close()
        model.close()
    }
}
