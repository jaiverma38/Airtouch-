package com.airtouchlocal

import kotlin.math.hypot

enum class Pose { NONE, POINT, SCROLL, FIST, PALM, THREE, OTHER }

/**
 * Shared hand-geometry helpers. All inputs are 21 landmarks in MediaPipe order
 * with x already multiplied by the image aspect ratio (so x and y share a unit).
 */
object Features {

    private fun d(xs: FloatArray, ys: FloatArray, a: Int, b: Int): Float =
        hypot(xs[a] - xs[b], ys[a] - ys[b])

    private fun extended(xs: FloatArray, ys: FloatArray, tip: Int, pip: Int): Boolean =
        d(xs, ys, tip, 0) > d(xs, ys, pip, 0) * 1.08f

    fun classify(xs: FloatArray, ys: FloatArray): Pose {
        val i = extended(xs, ys, 8, 6)
        val m = extended(xs, ys, 12, 10)
        val r = extended(xs, ys, 16, 14)
        val p = extended(xs, ys, 20, 18)
        return when {
            i && !m && !r && !p -> Pose.POINT
            i && m && !r && !p -> Pose.SCROLL
            i && m && r && !p -> Pose.THREE
            !i && !m && !r && !p -> Pose.FIST
            i && m && r && p -> Pose.PALM
            else -> Pose.OTHER
        }
    }

    /**
     * Position/scale/rotation-invariant description of the hand:
     * wrist at origin, wrist->middle-knuckle pointing "up", scaled to length 1.
     * Returns 42 floats (x0,y0,x1,y1,...).
     */
    fun extract(xs: FloatArray, ys: FloatArray): FloatArray {
        val wx = xs[0]
        val wy = ys[0]
        val vx = xs[9] - wx
        val vy = ys[9] - wy
        val size = hypot(vx, vy).coerceAtLeast(1e-4f)
        val ux = vx / size
        val uy = vy / size
        val c = -uy
        val s = -ux
        val out = FloatArray(xs.size * 2)
        for (k in xs.indices) {
            val px = xs[k] - wx
            val py = ys[k] - wy
            out[2 * k] = (px * c - py * s) / size
            out[2 * k + 1] = (px * s + py * c) / size
        }
        return out
    }

    /** Mean landmark-to-landmark distance between two extracted feature vectors. */
    fun distance(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size) / 2
        if (n == 0) return Float.MAX_VALUE
        var sum = 0f
        for (k in 0 until n) sum += hypot(a[2 * k] - b[2 * k], a[2 * k + 1] - b[2 * k + 1])
        return sum / n
    }
}
