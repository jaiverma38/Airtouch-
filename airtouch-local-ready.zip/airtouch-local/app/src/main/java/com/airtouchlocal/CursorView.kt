package com.airtouchlocal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Full-screen, non-touchable overlay that draws the air-cursor and, while a new
 * gesture is being recorded, a live skeleton preview of the tracked hand.
 */
class CursorView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2.5f * density
    }

    // cursor
    private var x = 0f
    private var y = 0f
    private var shown = false
    private var pressed = false

    // preview
    private var pvOn = false
    private var pvX: FloatArray? = null
    private var pvY: FloatArray? = null
    private var pvAspect = 0.75f
    private var pvRec = false
    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(200, 12, 16, 24)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
    }
    private val bonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3f * density
        color = Color.argb(230, 120, 200, 255)
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 14f * density
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val trail = ArrayList<Float>()
    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 4f * density
        color = Color.argb(230, 255, 171, 64)
    }

    private val bones = intArrayOf(
        0, 1, 1, 2, 2, 3, 3, 4,
        0, 5, 5, 6, 6, 7, 7, 8,
        5, 9, 9, 10, 10, 11, 11, 12,
        9, 13, 13, 14, 14, 15, 15, 16,
        13, 17, 17, 18, 18, 19, 19, 20,
        0, 17
    )

    fun update(nx: Float, ny: Float, isPressed: Boolean) {
        x = nx; y = ny; pressed = isPressed; shown = true
        invalidate()
    }

    fun hide() {
        if (shown) { shown = false; invalidate() }
    }

    /** [xs]/[ys] are 21 normalized landmarks of the upright, mirrored camera image, or null if no hand. */
    fun setPreview(xs: FloatArray?, ys: FloatArray?, aspect: Float, recording: Boolean) {
        pvX = xs; pvY = ys; pvAspect = if (aspect > 0.2f) aspect else 0.75f; pvRec = recording
        if (xs != null && ys != null && xs.size >= 21 && ys.size >= 21) {
            trail.add(xs[9]); trail.add(ys[9])
            while (trail.size > 120) { trail.removeAt(0); trail.removeAt(0) }
        }
        pvOn = true
        shown = false
        invalidate()
    }

    fun clearPreview() {
        if (pvOn) { pvOn = false; pvX = null; pvY = null; trail.clear(); invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        if (pvOn) drawPreview(canvas)
        if (!shown) return
        val r = (if (pressed) 13f else 20f) * density
        fill.color = if (pressed) Color.argb(200, 255, 82, 82) else Color.argb(140, 33, 150, 243)
        canvas.drawCircle(x, y, r, fill)
        canvas.drawCircle(x, y, r, ring)
    }

    private fun drawPreview(canvas: Canvas) {
        val w = width * 0.5f
        val h = w / pvAspect
        val left = (width - w) / 2f
        val top = 64f * density
        rect.set(left, top, left + w, top + h)
        val radius = 14f * density
        canvas.drawRoundRect(rect, radius, radius, panelPaint)
        borderPaint.color = if (pvRec) Color.rgb(76, 217, 100) else Color.WHITE
        canvas.drawRoundRect(rect, radius, radius, borderPaint)

        val xs = pvX
        val ys = pvY
        if (xs == null || ys == null || xs.size < 21 || ys.size < 21) {
            canvas.drawText("Haath nahi dikh raha", rect.centerX(), rect.centerY(), textPaint)
        } else {
            var i = 0
            while (i < bones.size) {
                val a = bones[i]
                val b = bones[i + 1]
                canvas.drawLine(
                    left + xs[a] * w, top + ys[a] * h,
                    left + xs[b] * w, top + ys[b] * h, bonePaint
                )
                i += 2
            }
            for (k in 0 until 21) {
                val rr = (if (k == 4 || k == 8 || k == 12 || k == 16 || k == 20) 5f else 3.5f) * density
                canvas.drawCircle(left + xs[k] * w, top + ys[k] * h, rr, dotPaint)
            }
        }
        var t = 2
        while (t + 1 < trail.size) {
            canvas.drawLine(
                left + trail[t - 2] * w, top + trail[t - 1] * h,
                left + trail[t] * w, top + trail[t + 1] * h, trailPaint
            )
            t += 2
        }
        val label = if (pvRec) "● REC: pose pakde rakho" else "Preview: pose banao"
        canvas.drawText(label, rect.centerX(), rect.top + 20f * density, textPaint)
    }
}
