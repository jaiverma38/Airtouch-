package com.airtouchlocal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Full-screen, non-touchable overlay that draws the air-cursor. */
class CursorView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2.5f * density
    }

    private var x = 0f
    private var y = 0f
    private var shown = false
    private var pressed = false

    fun update(nx: Float, ny: Float, isPressed: Boolean) {
        x = nx; y = ny; pressed = isPressed; shown = true
        invalidate()
    }

    fun hide() {
        if (shown) { shown = false; invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        if (!shown) return
        val r = (if (pressed) 13f else 20f) * density
        fill.color = if (pressed) Color.argb(200, 255, 82, 82) else Color.argb(140, 33, 150, 243)
        canvas.drawCircle(x, y, r, fill)
        canvas.drawCircle(x, y, r, ring)
    }
}
