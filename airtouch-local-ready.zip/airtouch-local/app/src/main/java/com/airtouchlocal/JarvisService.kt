package com.airtouchlocal

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import java.util.concurrent.Executors

/**
 * Always-listening Jarvis. Audio is processed on the phone only. A command runs only if
 * (1) the wake word was heard (or we are inside the follow-up window) AND
 * (2) the speaker's voice matches an enrolled owner voice.
 */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.airtouchlocal.JARVIS_STOP"
        private const val CHANNEL = "jarvis"
        private const val NOTIF_ID = 7
        private const val FOLLOW_UP_MS = 7000L

        @Volatile var instance: JarvisService? = null
        @Volatile var running = false

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, JarvisService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, JarvisService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private var thread: Thread? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var alive = false
    @Volatile private var speaking = false
    @Volatile private var needReset = false
    @Volatile private var activeUntil = 0L
    private var speakGen = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (_: Throwable) {
            stopSelf()
            return
        }
        tts = TextToSpeech(applicationContext, this)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "airtouch:jarvis").also { it.acquire() }
        } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (thread == null && instance === this) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                JarvisLog.add("Microphone permission nahi hai.")
                stopSelf()
                return START_NOT_STICKY
            }
            alive = true
            running = true
            thread = Thread({ engineLoop() }, "jarvis-engine").also { it.start() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        instance = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        net.shutdown()
        JarvisLog.status("Jarvis band hai")
        super.onDestroy()
    }

    // ---------------- TTS ----------------

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        val r = t.setLanguage(java.util.Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(java.util.Locale.US)
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finishSpeaking()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finishSpeaking()
        })
        ttsReady = true
    }

    private fun finishSpeaking() {
        main.postDelayed({
            speaking = false
            needReset = true
        }, 500)
    }

    private fun say(text: String) {
        if (text.isBlank()) return
        JarvisLog.add("Jarvis: $text")
        if (!SecureStore.speak(this) || !ttsReady) return
        speaking = true
        val gen = ++speakGen
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u$gen")
        main.postDelayed({
            if (gen == speakGen && speaking) {
                speaking = false
                needReset = true
            }
        }, 20_000)
    }

    // ---------------- engine ----------------

    private fun engineLoop() {
        var model: Model? = null
        var spk: SpeakerModel? = null
        var rec: Recognizer? = null
        var ar: AudioRecord? = null
        try {
            if (!SecureStore.hasVoice(this)) {
                JarvisLog.status("Pehle apni awaaz enroll karo")
                JarvisLog.add("Voice enroll nahi hai, Jarvis kuch nahi karega.")
                main.post { stopSelf() }
                return
            }
            if (!ModelFiles.ready(this)) {
                ModelFiles.ensure(this) { JarvisLog.status(it) }
            }
            JarvisLog.status("Jarvis load ho raha hai...")
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            model = Model(ModelFiles.dir(this, ModelFiles.ASR).absolutePath)
            spk = SpeakerModel(ModelFiles.dir(this, ModelFiles.SPK).absolutePath)
            rec = Recognizer(model, 16000.0f, spk)

            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 32000)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                JarvisLog.add("Microphone start nahi hua (koi aur app use kar rahi ho sakti hai).")
                main.post { stopSelf() }
                return
            }
            ar.startRecording()
            JarvisLog.status("Sun raha hu: bolo \"Jarvis ...\"")
            JarvisLog.add("Taiyar. Bolo: Jarvis, <command>")
            main.post { say("Jarvis online.") }

            val buf = ShortArray(2048)
            var failures = 0
            while (alive) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) {
                    if (++failures > 200) break
                    Thread.sleep(20)
                    continue
                }
                failures = 0
                if (speaking) continue
                if (needReset) {
                    rec.reset()
                    needReset = false
                }
                if (rec.acceptWaveForm(buf, n)) {
                    handleResult(rec.result)
                }
            }
        } catch (e: Throwable) {
            JarvisLog.add("Error: " + (e.message ?: e.javaClass.simpleName))
            JarvisLog.status("Error: " + (e.message ?: ""))
        } finally {
            try { ar?.stop() } catch (_: Throwable) {}
            try { ar?.release() } catch (_: Throwable) {}
            try { rec?.close() } catch (_: Throwable) {}
            try { spk?.close() } catch (_: Throwable) {}
            try { model?.close() } catch (_: Throwable) {}
            thread = null
            if (alive) main.post { stopSelf() }
        }
    }

    private fun handleResult(json: String) {
        val o = try { JSONObject(json) } catch (_: Throwable) { return }
        val text = o.optString("text", "").trim()
        if (text.isEmpty()) return
        val tokens = CommandParser.tokenize(text)
        val afterWake = CommandParser.stripWake(tokens)
        val active = System.currentTimeMillis() < activeUntil
        if (afterWake == null && !active) return   // not meant for Jarvis: ignore, do nothing

        // ---- voice check (owner only) ----
        val vec = VoiceMath.parse(o.optJSONArray("spk"))
        val profiles = SecureStore.profiles(this)
        if (vec == null) {
            JarvisLog.add("(awaaz bahut chhoti, verify nahi hui: \"$text\")")
            return
        }
        var best = 2f
        for (p in profiles) best = minOf(best, VoiceMath.cosineDistance(vec, p.vec))
        if (SecureStore.showDistance(this)) {
            val d = String.format("%.2f", best)
            main.post { Toast.makeText(applicationContext, "Voice distance $d", Toast.LENGTH_SHORT).show() }
        }
        if (best > SecureStore.threshold(this)) {
            SecureStore.logIntruder(this, best)
            JarvisLog.add("Anjaan awaaz block ki (distance " + String.format("%.2f", best) + ")")
            return
        }

        // ---- owner confirmed ----
        JarvisLog.add("Aap: $text")
        val cmdTokens = afterWake ?: tokens
        if (cmdTokens.isEmpty()) {
            activeUntil = System.currentTimeMillis() + FOLLOW_UP_MS
            main.post { say("Ji, boliye.") }
            return
        }
        val cmd = CommandParser.parse(cmdTokens)
        activeUntil = System.currentTimeMillis() + FOLLOW_UP_MS
        when (cmd.kind) {
            Kind.UNKNOWN -> {
                if (OnlineBrain.available(this)) {
                    net.execute { onlineAnswer(cmdTokens.joinToString(" ")) }
                } else {
                    main.post { say("Samajh nahi aaya. Online mode off hai, to main sirf fixed commands samajhta hu.") }
                }
            }
            Kind.SLEEP -> {
                activeUntil = 0L
                main.post { say("Theek hai. Jab zarurat ho Jarvis bolna.") }
            }
            Kind.SHUTDOWN -> {
                main.post {
                    say("Alvida.")
                    main.postDelayed({ stopSelf() }, 1800)
                }
            }
            else -> main.post { say(JarvisActions.run(this, cmd)) }
        }
    }

    private fun onlineAnswer(text: String) {
        val ans = OnlineBrain.ask(this, text)
        main.post {
            if (ans == null) {
                say("Online jawab nahi mila. Internet ya API key check karo.")
            } else {
                val extra = ans.cmd?.let { JarvisActions.run(this, it) } ?: ""
                say(if (ans.say.isNotBlank()) ans.say else extra)
            }
        }
    }

    // ---------------- notification ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 11, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 12, Intent(this, JarvisActivity::class.java), flags)
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        return b.setContentTitle("Jarvis sun raha hai")
            .setContentText("Sirf owner ki awaaz se kaam karta hai. Awaaz phone se bahar nahi jaati.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
    }
}
