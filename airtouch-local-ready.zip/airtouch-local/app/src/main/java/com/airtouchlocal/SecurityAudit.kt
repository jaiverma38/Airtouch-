package com.airtouchlocal

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/** On-device checklist of common phone-security problems. Nothing leaves the phone. */
object SecurityAudit {

    data class Result(val score: Int, val problems: List<String>, val oks: List<String>, val spoken: String) {
        fun fullText(): String = buildString {
            append("Security score: $score/100\n")
            for (p in problems) append("⚠ ").append(p).append('\n')
            for (o in oks) append("✓ ").append(o).append('\n')
        }
    }

    fun run(c: Context): Result {
        val problems = ArrayList<String>()
        val oks = ArrayList<String>()
        var score = 100

        fun bad(pts: Int, msg: String) { problems.add(msg); score -= pts }

        // Screen lock
        val kg = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (kg.isDeviceSecure) oks.add("Screen lock (PIN/pattern/password) set hai")
        else bad(30, "Screen lock nahi hai: PIN ya fingerprint lagao")

        // Storage encryption
        try {
            val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val st = dpm.storageEncryptionStatus
            if (st == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE ||
                st == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER ||
                st == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY
            ) oks.add("Phone storage encrypted hai")
            else bad(15, "Phone storage encrypted nahi dikh raha")
        } catch (_: Throwable) {}

        // USB debugging / developer options
        try {
            val adb = Settings.Global.getInt(c.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
            if (adb) bad(15, "USB debugging ON hai: jab zarurat na ho band karo")
            else oks.add("USB debugging band hai")
        } catch (_: Throwable) {}

        // Root hints
        val rootPaths = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk", "/data/local/xbin/su")
        val rooted = rootPaths.any { File(it).exists() } || (Build.TAGS?.contains("test-keys") == true)
        if (rooted) bad(25, "Phone rooted / custom build lag raha hai (risky)") else oks.add("Root ke nishaan nahi mile")

        // Security patch age
        try {
            val patch = Build.VERSION.SECURITY_PATCH
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(patch)
            if (d != null) {
                val days = (System.currentTimeMillis() - d.time) / 86_400_000L
                if (days > 365) bad(10, "Security patch purana hai ($patch). System update karo")
                else oks.add("Security patch theek hai ($patch)")
            }
        } catch (_: Throwable) {}

        // Enabled accessibility services (powerful: can read screen & tap)
        try {
            val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val others = enabled.split(':').filter { it.isNotBlank() && !it.startsWith(c.packageName) }
            if (others.isNotEmpty()) {
                val names = others.map { it.substringBefore('/') }.joinToString(", ")
                bad(10, "Dusre accessibility services ON hain ($names): sirf bharose wale rakho")
            } else oks.add("Koi anjaan accessibility service nahi")
        } catch (_: Throwable) {}

        // Sideloaded launcher apps
        try {
            val pm = c.packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val side = ArrayList<String>()
            for (ri in pm.queryIntentActivities(main, 0)) {
                val ai = ri.activityInfo.applicationInfo
                if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
                if (ai.packageName == c.packageName) continue
                val installer = if (Build.VERSION.SDK_INT >= 30)
                    pm.getInstallSourceInfo(ai.packageName).installingPackageName
                else
                    pm.getInstallerPackageName(ai.packageName)
                if (installer == null) side.add(ri.loadLabel(pm).toString())
            }
            if (side.size > 3) bad(10, "${side.size} apps Play Store ke bahar se install hain (${side.take(4).joinToString(", ")}...)")
            else oks.add("Sideloaded apps kam hain (${side.size})")
        } catch (_: Throwable) {}

        // Voice lock state
        if (SecureStore.hasVoice(c)) oks.add("Jarvis voice lock chalu hai")
        else bad(5, "Jarvis me apni awaaz enroll nahi ki")
        val intr = SecureStore.intruderCount(c)
        if (intr > 0) problems.add("Jarvis ko $intr baar anjaan awaaz se command mili (block ho gayi)")

        if (score < 0) score = 0
        val spoken = if (problems.isEmpty())
            "Phone ki security achhi hai. Score $score."
        else
            "Security score $score. ${problems.size} masle mile. Pehla: ${problems[0]}."
        return Result(score, problems, oks, spoken)
    }
}
