package com.airtouchlocal

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/** Things a custom gesture can trigger. */
enum class ActionType(val label: String, val minSdk: Int = 26) {
    NONE("Kuch nahi (band karo)"),
    BACK("Back"),
    HOME("Home"),
    RECENTS("Recent apps"),
    NOTIFICATIONS("Notification panel kholo"),
    QUICK_SETTINGS("Quick settings kholo"),
    LOCK_SCREEN("Screen lock karo", 28),
    SCREENSHOT("Screenshot lo", 28),
    TAP("Cursor ki jagah tap"),
    LONG_PRESS("Cursor ki jagah long press"),
    SCROLL_DOWN("Scroll neeche"),
    SCROLL_UP("Scroll upar"),
    SWIPE_LEFT("Screen swipe LEFT (ungli right se left)"),
    SWIPE_RIGHT("Screen swipe RIGHT (ungli left se right)"),
    VOLUME_UP("Volume badhao"),
    VOLUME_DOWN("Volume ghatao"),
    PLAY_PAUSE("Music play / pause"),
    OPEN_APP("Koi app kholo"),
    TOGGLE_PAUSE("AirTouch on / off (pause-resume)"),
    SCROLL_MODE("Scroll (haath upar/neeche hilao)");

    companion object {
        fun from(name: String): ActionType? = values().firstOrNull { it.name == name }
        fun available(): List<ActionType> = values().filter { Build.VERSION.SDK_INT >= it.minSdk }
        fun forCustom(): List<ActionType> = available().filter { it != NONE && it != SCROLL_MODE }
        fun forBuiltin(): List<ActionType> = available()
    }
}

/** A recorded static hand pose plus the action it triggers. */
class CustomGesture(
    val id: String,
    val name: String,
    val action: String,        // ActionType name
    val arg: String?,          // e.g. package name for OPEN_APP
    val template: FloatArray,  // pose: Features.extract(...) ; motion: resampled path (MotionTracker.N points)
    val kind: String = "pose", // "pose" (hold a hand shape) or "motion" (move the hand)
    val poseName: String? = null // motion only: hand shape (Pose name) used while moving
)

/** Local storage for custom gestures (only landmark numbers, no images). */
object GestureStore {
    @Volatile
    var list: List<CustomGesture> = emptyList()
        private set

    private fun sp(c: Context) = c.getSharedPreferences("airtouch_gestures", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val raw = sp(c).getString("list", "[]") ?: "[]"
        val out = ArrayList<CustomGesture>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.getJSONArray("template")
                out.add(
                    CustomGesture(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        action = o.getString("action"),
                        arg = if (o.isNull("arg")) null else o.getString("arg"),
                        template = FloatArray(t.length()) { t.getDouble(it).toFloat() },
                        kind = o.optString("kind", "pose"),
                        poseName = o.optString("pose", "").takeIf { it.isNotEmpty() && it != "null" }
                    )
                )
            }
        } catch (_: Throwable) {
            // corrupted store: start empty
        }
        list = out
    }

    fun add(c: Context, g: CustomGesture) {
        list = list + g
        save(c)
    }

    fun remove(c: Context, id: String) {
        list = list.filter { it.id != id }
        save(c)
    }

    private fun save(c: Context) {
        val arr = JSONArray()
        for (g in list) {
            val t = JSONArray()
            g.template.forEach { t.put(it.toDouble()) }
            arr.put(
                JSONObject()
                    .put("id", g.id)
                    .put("name", g.name)
                    .put("action", g.action)
                    .put("arg", g.arg ?: JSONObject.NULL)
                    .put("template", t)
                    .put("kind", g.kind)
                    .put("pose", g.poseName ?: JSONObject.NULL)
            )
        }
        sp(c).edit().putString("list", arr.toString()).apply()
    }
}
