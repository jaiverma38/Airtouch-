package com.airtouchlocal

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * Turns 21 hand landmarks (MediaPipe order, normalized 0..1, image already
 * upright + mirrored) into phone actions. Pure Kotlin, no Android deps.
 *
 * Built-in gestures: point = cursor, pinch = tap / long press, two fingers =
 * scroll, fist hold = Back, open palm hold = Home, three fingers hold = pause/resume.
 * Custom gestures (recorded static poses) are matched first and win over built-ins.
 */
class GestureEngine(private val sink: Sink, private val settings: Settings) {

    interface Sink {
        val screenWidth: Int
        val screenHeight: Int
        fun onCursor(x: Float, y: Float, pressed: Boolean)
        fun onTap(x: Float, y: Float)
        /** [swipeUp] = the synthetic finger should swipe upward. */
        fun onScroll(swipeUp: Boolean)
        fun onHandLost()
        /** Any configurable action (built-in or custom gesture). TOGGLE_PAUSE never arrives here. */
        fun onAction(action: ActionType, arg: String?, x: Float, y: Float)
        fun onPausedChanged(paused: Boolean)
        /** Live hand skeleton while a gesture is being recorded; null arrays = no hand visible. */
        fun onPreview(xs: FloatArray?, ys: FloatArray?, aspect: Float, recording: Boolean)
        fun onPreviewEnd()
        /** Short debug text for the movement-gesture "debug" switch. */
        fun onDebug(msg: String)
    }

    interface Settings {
        val speed: Int               // 0..100
        val invertScroll: Boolean
        val strictness: Int          // 0..100, custom gesture matching
        val gestures: List<CustomGesture>
        fun actionFor(b: BuiltIn): ActionType
        fun argFor(b: BuiltIn): String?
        fun holdMs(b: BuiltIn): Long
        val debug: Boolean
    }

    private companion object {
        const val PINCH_ON = 0.30f
        const val PINCH_OFF = 0.45f
        const val PRE_PINCH = 0.55f       // freeze cursor while fingers approach
        const val MIN_TAP_MS = 40L
        const val TAP_COOLDOWN_MS = 250L
        const val SCROLL_STEP = 0.06f
        const val SCROLL_COOLDOWN_MS = 280L
        const val CUSTOM_HOLD_MS = 700L
        const val ACTION_COOLDOWN_MS = 1500L
        const val HAND_LOST_MS = 400L
        const val HIST = 6
        const val MOTION_GAP_MS = 250L
        const val RECORD_MS = 1500L
        const val RECORD_MIN_FRAMES = 10
        const val RECORD_MAX_WOBBLE = 0.12f
    }

    // ---- pause (on/off) ----
    @Volatile
    var paused = false
        private set
    @Volatile
    private var pendingToggle = false

    /** Safe to call from any thread; applied on the next camera frame. */
    fun togglePause() {
        pendingToggle = true
    }

    // ---- capture mode: preview only, no gestures are executed ----
    @Volatile
    var captureMode = false
        private set
    private var wasCapture = false

    fun setCapture(on: Boolean) {
        captureMode = on
        if (on) sink.onHandLost() else sink.onPreviewEnd()
    }

    // ---- recording a new custom gesture ----
    private class Recorder(val startMs: Long, val onDone: (FloatArray?, String?) -> Unit) {
        val frames = ArrayList<FloatArray>()
    }

    @Volatile
    private var rec: Recorder? = null

    // ---- movement (motion) gestures ----
    private val motion = MotionTracker()
    private var motionBlockUntil = 0L

    private class MotionRecorder(
        val startMs: Long,
        val onDone: (FloatArray?, String?, String?) -> Unit
    ) {
        var started = false
    }

    @Volatile
    private var motionRec: MotionRecorder? = null

    /** Records one hand movement. [onDone] gets (path, poseName, error). */
    fun startMotionRecording(nowMs: Long, onDone: (FloatArray?, String?, String?) -> Unit) {
        motionRec = MotionRecorder(nowMs, onDone)
    }

    fun cancelMotionRecording() {
        motionRec = null
    }

    /** Collects ~1.5 s of frames and returns the averaged template (or an error text). */
    fun startRecording(nowMs: Long, onDone: (FloatArray?, String?) -> Unit) {
        rec = Recorder(nowMs, onDone)
    }

    fun cancelRecording() {
        rec = null
    }

    // pose debouncing
    private var stablePose = Pose.NONE
    private var cand = Pose.NONE
    private var candCount = 0
    private var poseSince = 0L
    private var poseFired = false
    private var lastAction = 0L
    private var lastPointMs = 0L

    // custom match state
    private var matchId: String? = null
    private var matchSince = 0L
    private var matchFired = false
    private var missCount = 0

    // cursor
    private var cx = 0f
    private var cy = 0f
    private var cursorInit = false
    private var frozen = false
    private val histX = FloatArray(HIST)
    private val histY = FloatArray(HIST)
    private var histN = 0

    // pinch
    private var pinching = false
    private var pinchStart = 0L
    private var longFired = false
    private var pinchX = 0f
    private var pinchY = 0f
    private var lastTap = 0L

    // scroll
    private var scrolling = false
    private var anchorY = 0f
    private var lastScroll = 0L

    private var hadHand = false
    private var lastSeen = 0L

    /**
     * @param aspect width/height of the upright camera frame, so x and y distances
     * are measured in the same unit.
     */
    fun process(xs: FloatArray?, ys: FloatArray?, now: Long, aspect: Float) {
        if (pendingToggle) {
            pendingToggle = false
            applyPause(!paused, now)
        }
        checkRecording(now)

        if (captureMode || rec != null || motionRec != null) {
            wasCapture = true
            val r = rec
            val mr = motionRec
            sink.onPreview(xs, ys, aspect, r != null || mr != null)
            if (r != null && xs != null && ys != null) {
                val gxr = FloatArray(xs.size) { xs[it] * aspect }
                r.frames.add(Features.extract(gxr, ys))
            }
            if (mr != null) handleMotionRecording(mr, xs, ys, aspect, now)
            return
        }
        if (wasCapture) {
            wasCapture = false
            reset()
        }

        if (xs == null || ys == null) {
            motionHandMissing(now)
            if (hadHand && now - lastSeen > HAND_LOST_MS) {
                reset()
                sink.onHandLost()
            }
            return
        }
        hadHand = true
        lastSeen = now

        val sw = sink.screenWidth.toFloat()
        val sh = sink.screenHeight.toFloat()
        if (sw <= 0f || sh <= 0f) return

        val gx = FloatArray(xs.size) { xs[it] * aspect }

        val raw = Features.classify(gx, ys)
        if (raw == Pose.POINT) lastPointMs = now
        updateStablePose(raw, now)

        // movement gestures (swipe, circle...): while one is being tracked, nothing else runs
        val blocked = stablePose == Pose.POINT || stablePose == Pose.SCROLL
        if (!pinching && processMotion(gx, ys, blocked, now)) return

        // custom gestures win over built-ins
        if (matchCustom(gx, ys, now)) return

        if (paused) {
            holdActions(now)
            return
        }

        val handSize = max(hypot(gx[0] - gx[9], ys[0] - ys[9]), 1e-4f)
        val ratio = hypot(gx[4] - gx[8], ys[4] - ys[8]) / handSize

        // ---- pinch state (hysteresis) ----
        if (!pinching) {
            if (ratio < PINCH_ON && now - lastPointMs < 350 && now - lastTap > TAP_COOLDOWN_MS) {
                pinching = true
                pinchStart = now
                longFired = false
                pinchX = cx
                pinchY = cy
            }
        } else if (ratio > PINCH_OFF) {
            pinching = false
            if (!longFired && now - pinchStart > MIN_TAP_MS) {
                lastTap = now
                sink.onTap(pinchX, pinchY)
            }
        }
        if (pinching && !longFired) {
            val a = settings.actionFor(BuiltIn.PINCH_HOLD)
            if (a != ActionType.NONE && now - pinchStart > settings.holdMs(BuiltIn.PINCH_HOLD)) {
                longFired = true
                if (a == ActionType.TOGGLE_PAUSE) {
                    applyPause(true, now)
                } else {
                    sink.onAction(a, settings.argFor(BuiltIn.PINCH_HOLD), pinchX, pinchY)
                }
            }
        }

        // ---- cursor ----
        val near = ratio < PRE_PINCH && (raw == Pose.POINT || pinching)
        if (near && !frozen && histN > 0) {
            // rewind to where the fingertip was ~150 ms ago, before the pinch wobble
            cx = histX[0]
            cy = histY[0]
        }
        frozen = near

        if (!frozen && stablePose == Pose.POINT) {
            val gain = 1.3f + settings.speed / 100f * 1.7f
            val tx = (0.5f + (xs[8] - 0.5f) * gain).coerceIn(0f, 1f) * sw
            val ty = (0.5f + (ys[8] - 0.5f) * gain).coerceIn(0f, 1f) * sh
            if (!cursorInit) {
                cx = tx; cy = ty; cursorInit = true
            } else {
                val d = hypot(tx - cx, ty - cy) / sw
                val alpha = (0.12f + d * 10f).coerceIn(0.12f, 0.85f)
                cx += (tx - cx) * alpha
                cy += (ty - cy) * alpha
            }
            pushHistory()
        } else if (!cursorInit) {
            cx = sw / 2; cy = sh / 2; cursorInit = true
        }
        sink.onCursor(cx, cy, pinching)

        if (pinching) return

        // ---- scroll (two fingers up) ----
        if (stablePose == Pose.SCROLL) {
            val y = (ys[8] + ys[12]) / 2f
            if (!scrolling) {
                scrolling = true
                anchorY = y
            }
            val dy = y - anchorY
            if (abs(dy) > SCROLL_STEP && now - lastScroll > SCROLL_COOLDOWN_MS) {
                val swipeUp = dy < 0f           // hand up -> finger swipes up
                sink.onScroll(swipeUp != settings.invertScroll)
                anchorY = y
                lastScroll = now
            }
        } else {
            scrolling = false
        }

        holdActions(now)
    }

    fun reset() {
        hadHand = false
        pinching = false
        frozen = false
        scrolling = false
        stablePose = Pose.NONE
        cand = Pose.NONE
        candCount = 0
        histN = 0
        matchId = null
        missCount = 0
        motion.reset()
    }

    // ---------- pause ----------

    private fun applyPause(p: Boolean, now: Long) {
        paused = p
        // Keep stablePose as-is and mark it fired, so holding the pose does not toggle again.
        poseFired = true
        lastAction = now
        pinching = false
        scrolling = false
        frozen = false
        sink.onPausedChanged(p)
        if (p) sink.onHandLost()
    }

    // ---------- hold-to-trigger built-ins ----------

    private fun holdActions(now: Long) {
        if (poseFired || now - lastAction <= ACTION_COOLDOWN_MS) return
        val b = when (stablePose) {
            Pose.FIST -> BuiltIn.FIST
            Pose.PALM -> BuiltIn.PALM
            Pose.THREE -> BuiltIn.THREE
            else -> return
        }
        val a = settings.actionFor(b)
        if (a == ActionType.NONE) return
        if (paused && a != ActionType.TOGGLE_PAUSE) return   // while paused only resume works
        if (now - poseSince <= settings.holdMs(b)) return
        poseFired = true
        lastAction = now
        if (a == ActionType.TOGGLE_PAUSE) {
            applyPause(!paused, now)
        } else {
            sink.onAction(a, settings.argFor(b), cx, cy)
        }
    }

    // ---------- custom gestures ----------

    /** Returns true if a custom gesture matches this frame (built-ins are then skipped). */
    private fun matchCustom(gx: FloatArray, ys: FloatArray, now: Long): Boolean {
        val list = settings.gestures
        if (list.isEmpty() || pinching) {
            matchId = null
            return false
        }
        val f = Features.extract(gx, ys)
        val threshold = 0.30f - settings.strictness.coerceIn(0, 100) / 100f * 0.20f

        var best: CustomGesture? = null
        var bestD = Float.MAX_VALUE
        for (g in list) {
            if (g.kind != "pose") continue
            if (paused && g.action != ActionType.TOGGLE_PAUSE.name) continue
            val d = Features.distance(f, g.template)
            if (d < bestD) {
                bestD = d
                best = g
            }
        }

        if (best != null && bestD < threshold) {
            missCount = 0
            if (best.id != matchId) {
                matchId = best.id
                matchSince = now
                matchFired = false
            }
            if (!matchFired && now - matchSince >= CUSTOM_HOLD_MS && now - lastAction > ACTION_COOLDOWN_MS) {
                matchFired = true
                lastAction = now
                if (best.action == ActionType.TOGGLE_PAUSE.name) {
                    applyPause(!paused, now)
                } else {
                    ActionType.from(best.action)?.let { sink.onAction(it, best.arg, cx, cy) }
                }
            }
            return true
        }

        // tolerate a few missed frames before forgetting the current match
        if (++missCount > 3) matchId = null
        return false
    }

    // ---------- movement gestures ----------

    private var motionLostSince = 0L

    private fun handSize(gx: FloatArray, ys: FloatArray): Float =
        max(hypot(gx[0] - gx[9], ys[0] - ys[9]), 1e-4f)

    private fun debug(msg: String) {
        if (settings.debug) sink.onDebug(msg)
    }

    /** Hand not visible this frame: a short gap is tolerated, a longer one ends the movement. */
    private fun motionHandMissing(now: Long) {
        if (!motion.isCollecting) {
            motionLostSince = 0L
            return
        }
        if (motionLostSince == 0L) {
            motionLostSince = now
            return
        }
        if (now - motionLostSince > MOTION_GAP_MS) {
            motionLostSince = 0L
            handleMotionResult(motion.finishNow(now), now)
        }
    }

    private fun handleMotionResult(res: MotionTracker.Result?, now: Long): Boolean {
        if (res == null) {
            motion.takeReject()?.let { debug(it) }
            return false
        }
        return matchMotion(res, now)
    }

    /** Returns true while a movement is being tracked or just fired. */
    private fun processMotion(gx: FloatArray, ys: FloatArray, blocked: Boolean, now: Long): Boolean {
        var any = false
        for (g in settings.gestures) if (g.kind == "motion") { any = true; break }
        if (!any) {
            motion.reset()
            return false
        }
        if (now < motionBlockUntil) {
            motion.reset()
            return false
        }
        motionLostSince = 0L
        val res = motion.feed(
            MotionTracker.centerX(gx), MotionTracker.centerY(ys), handSize(gx, ys), blocked, now
        )
        if (handleMotionResult(res, now)) return true
        return motion.isCollecting
    }

    private fun matchMotion(res: MotionTracker.Result, now: Long): Boolean {
        val threshold = 1.2f - settings.strictness.coerceIn(0, 100) / 100f * 0.7f
        val len = MotionTracker.pathLength(res.path)
        var best: CustomGesture? = null
        var bestD = Float.MAX_VALUE
        var tried = 0
        for (g in settings.gestures) {
            if (g.kind != "motion") continue
            if (paused && g.action != ActionType.TOGGLE_PAUSE.name) continue
            tried++
            val ratio = len / max(MotionTracker.pathLength(g.template), 1e-3f)
            if (ratio < 0.5f || ratio > 2.0f) continue
            val d = MotionTracker.distance(res.path, g.template)
            if (d < bestD) {
                bestD = d
                best = g
            }
        }
        if (best == null) {
            if (tried > 0) debug("Movement mila par lambai match nahi hui (${"%.1f".format(len)}). Record jitna hi bada/chhota hilao.")
            return false
        }
        if (bestD >= threshold) {
            debug("Match nahi hua: '${best.name}' farak ${"%.2f".format(bestD)} (limit ${"%.2f".format(threshold)}). Matching slider dheela karo.")
            return false
        }
        debug("✔ '${best.name}' (farak ${"%.2f".format(bestD)})")
        lastAction = now
        poseFired = true
        motionBlockUntil = now + 800L
        if (best.action == ActionType.TOGGLE_PAUSE.name) {
            applyPause(!paused, now)
        } else {
            ActionType.from(best.action)?.let { sink.onAction(it, best.arg, cx, cy) }
        }
        return true
    }

    private fun handleMotionRecording(
        mr: MotionRecorder, xs: FloatArray?, ys: FloatArray?, aspect: Float, now: Long
    ) {
        if (!mr.started) {
            mr.started = true
            motionLostSince = 0L
            motion.reset()
        }
        var res: MotionTracker.Result? = null
        if (xs != null && ys != null) {
            motionLostSince = 0L
            val gx = FloatArray(xs.size) { xs[it] * aspect }
            res = motion.feed(
                MotionTracker.centerX(gx), MotionTracker.centerY(ys), handSize(gx, ys), false, now
            )
        } else if (motion.isCollecting) {
            if (motionLostSince == 0L) {
                motionLostSince = now
            } else if (now - motionLostSince > MOTION_GAP_MS) {
                motionLostSince = 0L
                res = motion.finishNow(now)
            }
        }
        if (res != null) {
            motionRec = null
            motion.reset()
            mr.onDone(res.path, "ANY", null)
            return
        }
        if (now - mr.startMs > 8000L && !motion.isCollecting) {
            motionRec = null
            motion.reset()
            mr.onDone(null, null, "Koi movement nahi dikha. Haath thoda tez aur bada hilao (swipe / circle), phir ruk jao.")
        }
    }

    private fun checkRecording(now: Long) {
        val r = rec ?: return
        if (now - r.startMs < RECORD_MS) return
        rec = null
        val n = r.frames.size
        if (n < RECORD_MIN_FRAMES) {
            r.onDone(null, "Haath theek se nahi dikha. Roshni me, camera ke saamne dobara try karo.")
            return
        }
        val len = r.frames[0].size
        val mean = FloatArray(len)
        val count = n.toFloat()
        for (fr in r.frames) {
            for (i in 0 until len) {
                mean[i] = mean[i] + fr[i]
            }
        }
        for (i in 0 until len) {
            mean[i] = mean[i] / count
        }

        var wobble = 0f
        for (fr in r.frames) wobble += Features.distance(fr, mean)
        wobble /= n
        if (wobble > RECORD_MAX_WOBBLE) {
            r.onDone(null, "Haath hil raha tha. Pose stable rakh ke dobara record karo.")
            return
        }
        r.onDone(mean, null)
    }

    // ---------- helpers ----------

    private fun pushHistory() {
        if (histN < HIST) {
            histX[histN] = cx; histY[histN] = cy; histN++
        } else {
            for (i in 0 until HIST - 1) { histX[i] = histX[i + 1]; histY[i] = histY[i + 1] }
            histX[HIST - 1] = cx; histY[HIST - 1] = cy
        }
    }

    private fun updateStablePose(raw: Pose, now: Long) {
        if (raw == stablePose) {
            candCount = 0
            return
        }
        if (raw == cand) candCount++ else { cand = raw; candCount = 1 }
        if (candCount >= 3) {
            stablePose = raw
            poseSince = now
            poseFired = false
            candCount = 0
        }
    }
}
