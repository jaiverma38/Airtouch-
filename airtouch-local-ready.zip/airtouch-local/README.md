# AirTouch Local

Haath ke gestures se phone control karne wala Android app. Front camera + MediaPipe hand tracking, sab kuch phone par hi chalta hai.
Camera frames aur mic ki awaaz **kabhi phone se bahar nahi jaate**. App me ab INTERNET permission hai, lekin sirf: (1) voice models ek baar download karne ke liye (agar APK me bundle na ho), (2) optional **Online mode** (default OFF) jo sirf command ka TEXT bhejta hai.

## Build (ek baar, computer par)

1. Android Studio (Koala ya naya) install karo.
2. `File > Open` se is folder (`airtouch-local`) ko kholo, Gradle sync hone do.
   Sync/build ke dauraan `hand_landmarker.task` (~8 MB model) apne aap `app/src/main/assets/` me download hota hai.
   Agar auto-download fail ho, to ye file khud download karke us folder me rakh do:
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
3. Phone par USB debugging ON karo, phone connect karo, Run dabao.
   Ya `Build > Build APK(s)` karke APK phone me install kar lo.

Model bundle hone ke baad app poori tarah offline chalta hai.

## Setup on phone

1. App kholo, **Accessibility service enable karo** (Settings me "AirTouch Local" ON karo).
   Android 13+ par sideload app ke liye pehle: Settings > Apps > AirTouch Local > ⋮ > **Allow restricted settings**.
2. **Tracking start karo**, camera permission do.
3. Haath front camera ke saamne 20–50 cm par, achhi roshni me rakho.

## Built-in gestures (customize kar sakte ho)

| Gesture | Default action |
|---|---|
| Sirf index finger upar | Cursor move (fixed) |
| Thumb + index pinch, phir chhodo | Tap (fixed) |
| Index + middle finger, haath upar/neeche | Scroll (default; "Built-in gestures badlo" me badal sakte ho, ya band kar sakte ho) |
| Mutthi 1 sec | Back |
| Khula panja 1.5 sec | Home |
| Teen ungliyan (index, middle, ring) 1.2 sec | AirTouch pause / resume |
| Pinch 0.6 sec pakdo | Long press |

Neeche wale chaar gestures ke liye app me **"Built-in gestures badlo"** section hai:
- **Badlo** dabao, naya action chuno (Back, Home, Recents, Screenshot, Volume, koi app kholo, ya "Kuch nahi" se band karo)
- Phir kitni der pakdna hai wo chuno (0.4 se 3 sec)
- "Default par laao" se sab wapas original ho jata hai

Dhyan: agar teen-ungliyan wale gesture ka action pause/resume se alag kar diya, to pause ke baad resume ke liye app ka ya notification ka Resume button use karna padega.

## AirTouch on / off

Pause ke dauraan koi gesture kaam nahi karta (sirf resume gesture), camera bahut kam frames process karta hai to battery bachti hai.
Teen tareeke:
- Teen ungliyan 1.2 sec pakdo
- App me "AirTouch Pause / Resume" button
- Notification me Pause / Resume button
(Tracking Stop karne se camera poori tarah band ho jata hai.)

## Custom gestures (bina coding ke)

App me **Custom gestures > + Naya gesture banao**:
1. Naam likho (jaise "Thumbs up")
2. Action chuno: Back, Home, Recents, Notifications, Quick settings, Screen lock, Screenshot, Tap, Scroll up/down, Volume up/down, Music play/pause, koi bhi app kholo, ya AirTouch on/off
3. Countdown ke baad apna pose banao aur ~1.5 sec stable rakho. Screen ke upar ek **live preview** dikhta hai: aapke haath ka skeleton (21 points), jaisa app use dekh raha hai. Haath nahi dikhe to "Haath nahi dikh raha" likha aata hai, record hote waqt border hara ho jata hai. Camera ki photo/video kahin nahi dikhti ya save hoti, sirf points ka drawing. Preview ke dauraan koi gesture action nahi chalta. App pose yaad kar leta hai (sirf haath ke 21 points ke numbers, koi photo nahi)

Tab se wo pose 0.7 sec pakdoge to action chalega. Dhyan rakhne wali baatein:
- **Pose** gestures static hote hain (haath ki shape). Hilane wale gestures ke liye neeche **Movement** section dekho.
- Pose built-in gestures se alag hona chahiye. Sirf-index-pointing aur two-finger (scroll) jaise poses app reject kar deta hai. Do gestures ke poses bhi alag hone chahiye.
- Agar galti se trigger ho to "Matching" slider sakht ki taraf karo. Trigger na ho to dheela karo.
- "App kholo" kuch phones par background se block ho sakta hai.

## Swipe gestures: left / right / upar / neeche (ready-made)

**Custom gestures > + Naya gesture banao** > naam > **Swipe** chuno. Direction chuno (Left, Right, Upar, Neeche), phir action. Record nahi karna padta.
- Haath ko us taraf seedha hilao (apne left / right / upar / neeche). Camera selfie jaisa mirror hai, to jo taraf aap haath le jaate ho wahi taraf mani jati hai.
- Swipe ke baad haath wapas aa jaye to bhi chalega, sirf pehla stroke dekha jaata hai.
- Har direction ke liye ek hi swipe ban sakta hai.
- Koi bhi haath ki shape chalegi (khula panja, mutthi), bas sirf-index-finger (cursor) ya do-ungliyan (scroll) se shuru mat karo.
- "Matching" slider: dheela = direction thodi tirchi bhi chalegi, sakht = bilkul seedhi.
- "Movement test mode" ON karo to toast me dikhta hai kya hua.

## Movement gestures (haath hilane wale)

**Custom gestures > + Naya gesture banao** me naam ke baad "Gesture kaisa hai?" poochta hai. **Movement** chuno:
1. Action chuno (Back, Home, Screenshot, app kholo, pause/resume...)
2. Countdown me haath ready rakho (khula panja ya mutthi, ya koi bhi shape)
3. "Ab haath hilao" dikhe to movement karo (swipe left/right/up/down, circle, wave...) aur phir **ruk jao**. Preview panel me narangi line se aapke haath ka raasta dikhta hai.

Kaise pehchanta hai:
- Haath ka beech ka point tez hilta hai to app raasta record karna shuru karta hai, ruk jane par raasta match karta hai.
- Direction matter karti hai (left swipe aur right swipe alag hain). Haath kitna door hai us se farak nahi padta.
- Sirf haath ka raasta dekha jaata hai, haath ki shape koi bhi chalegi (khula panja, mutthi...).
- Sirf-index-finger (cursor) ya do-ungliyan (scroll) wali shape se movement **shuru** nahi hota, kyunki wo cursor/scroll ke liye hain.
- Haath thodi der ke liye camera se bahar chala jaye (250 ms tak) to bhi movement poora maana jata hai.
- **Movement test mode** (app me Matching slider ke neeche ka switch) ON karo to har movement ke baad toast aata hai: match hua, ya kitna "farak" tha aur limit kitni thi. Isse pata chalta hai ki slider kitna dheela karna hai.
- Tips: swipe ke baad 0.3 sec ruko (haath wapas dheere laao, tez nahi), movement record jitna bada aur tez karo.
- "Matching" slider yahan bhi kaam karta hai: galti se trigger ho to sakht, trigger na ho to dheela.
- Trigger hone ke baad 0.8 sec tak naya movement nahi pakdata.

## Jarvis (voice assistant)

Main screen par **Jarvis** button. Pehli baar fingerprint/screen-lock se unlock hota hai (screenshots bhi blocked).
1. **Awaaz enroll karo**: 3 baar 5 sec bolo. Sirf awaaz ke numbers (speaker vector) encrypted store me save hote hain, recording nahi. Dusre owner ki awaaz bhi add kar sakte ho.
2. **Jarvis start karo**: notification ke saath mic sunta rehta hai. Bolo "Jarvis, ..." Command tabhi chalegi jab wake word suna ho aur awaaz enrolled awaaz se match kare. Command ke baad 7 sec tak bina "Jarvis" bole follow-up chalta hai.
3. Anjaan awaaz silently block hoti hai aur counter badhta hai.
4. "Voice matching" slider aur "Voice distance dikhao" se apni awaaz ke hisaab se tune karo.

Offline commands: back/home/recents/notifications/lock/screenshot, scroll, volume/mute, music play/pause/next/prev, torch, app kholo, naam ya number se call (dial screen khulti hai, call aap dabate ho), timer/alarm, time/date/battery, search, wifi/bluetooth settings, AirTouch on/off, security check, so jao, shutdown. Hindi/English/Hinglish (Roman script).
Online mode (optional): apni Anthropic API key daalo; jo samajh na aaye wo text ke roop me jata hai, jawab ya whitelist wale actions wapas aate hain (koi aur action nahi chalta).
Security check: screen lock, encryption, USB debugging, root, patch age, anjaan accessibility services, sideloaded apps.

Limits: voice lock recording-replay ya bahut milti awaaz ko 100% nahi rok sakta (ye koi bank-grade biometric nahi). Wifi/Bluetooth/airplane ko Android app se seedha on/off nahi karne deta. Mic chalu rehne se battery zyada lagti hai.

## Files

- `GestureEngine.kt`: built-in gestures, custom matching, recording, pause (thresholds upar companion object me)
- `Features.kt`: pose classification + rotation/scale-invariant hand features
- `CustomGesture.kt`: action list + local gesture storage
- `HandTracker.kt`: MediaPipe HandLandmarker wrapper
- `TrackingService.kt`: foreground service, CameraX front camera, notification
- `GestureAccessibilityService.kt`: cursor overlay + tap/swipe/global actions
- `MainActivity.kt`: setup screen, gesture recorder UI
- `Jarvis*.kt`, `CommandParser.kt`, `VoiceEnroller.kt`, `ModelFiles.kt`, `OnlineBrain.kt`, `SecurityAudit.kt`, `SecureStore.kt`: Jarvis

## Limits

- Camera background me tabhi chalta hai jab foreground service (notification) chal rahi ho. Koi aur app camera use kare to tracking ruk sakti hai.
- Banking apps / secure screens accessibility taps ko block kar sakti hain.
- Battery: camera + ML continuous chalta hai, to battery zyada khayega. Use na ho to Pause ya Stop kar do.
