# AirTouch Local

Haath ke gestures se phone control karne wala Android app. Front camera + MediaPipe hand tracking, sab kuch phone par hi chalta hai.
App me **INTERNET permission hai hi nahi**, to camera ka data phone se bahar ja hi nahi sakta.

## Build (ek baar, computer par)

1. Android Studio (Koala ya naya) install karo.
2. `File > Open` se is folder (`airtouch-local`) ko kholo, Gradle sync hone do.
   Sync/build ke dauraan `hand_landmarker.task` (~8 MB model) apne aap `app/src/main/assets/` me download hota hai.
   Agar auto-download fail ho, to ye file khud download karke us folder me rakh do:
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
3. Phone par USB debugging ON karo, phone connect karo, Run dabao.
   Ya `Build > Build APK(s)` karke APK phone me install kar lo.

Model bundle hone ke baad app poori tarah offline chalta hai.

## Setup on phone

1. App kholo, **Accessibility service enable karo** (Settings me "AirTouch Local" ON karo).
   Android 13+ par sideload app ke liye pehle: Settings > Apps > AirTouch Local > ⋮ > **Allow restricted settings**.
2. **Tracking start karo**, camera permission do.
3. Haath front camera ke saamne 20–50 cm par, achhi roshni me rakho.

## Built-in gestures

| Gesture | Action |
|---|---|
| Sirf index finger upar | Cursor move |
| Thumb + index pinch, phir chhodo | Tap |
| Pinch 0.6 sec pakdo | Long press |
| Index + middle finger, haath upar/neeche | Scroll |
| Mutthi 1 sec | Back |
| Khula panja 1.5 sec | Home |
| Teen ungliyan (index, middle, ring) 1.2 sec | **AirTouch pause / resume** |

## AirTouch on / off

Pause ke dauraan koi gesture kaam nahi karta (sirf resume gesture), camera bahut kam frames process karta hai to battery bachti hai.
Teen tareeke:
- Teen ungliyan 1.2 sec pakdo
- App me "AirTouch Pause / Resume" button
- Notification me Pause / Resume button
(Tracking Stop karne se camera poori tarah band ho jata hai.)

## Custom gestures (bina coding ke)

App me **Custom gestures > + Naya gesture banao**:
1. Naam likho (jaise "Thumbs up")
2. Action chuno: Back, Home, Recents, Notifications, Quick settings, Screen lock, Screenshot, Tap, Scroll up/down, Volume up/down, Music play/pause, koi bhi app kholo, ya AirTouch on/off
3. Countdown ke baad apna pose banao aur ~1.5 sec stable rakho. App pose yaad kar leta hai (sirf haath ke 21 points ke numbers, koi photo nahi)

Tab se wo pose 0.7 sec pakdoge to action chalega. Dhyan rakhne wali baatein:
- Ye **static poses** hain (haath ki shape). Haath ko hilaane wale swipe jaise gestures abhi nahi.
- Pose built-in gestures se alag hona chahiye. Sirf-index-pointing aur two-finger (scroll) jaise poses app reject kar deta hai. Do gestures ke poses bhi alag hone chahiye.
- Agar galti se trigger ho to "Matching" slider sakht ki taraf karo. Trigger na ho to dheela karo.
- "App kholo" kuch phones par background se block ho sakta hai.

## Files

- `GestureEngine.kt`: built-in gestures, custom matching, recording, pause (thresholds upar companion object me)
- `Features.kt`: pose classification + rotation/scale-invariant hand features
- `CustomGesture.kt`: action list + local gesture storage
- `HandTracker.kt`: MediaPipe HandLandmarker wrapper
- `TrackingService.kt`: foreground service, CameraX front camera, notification
- `GestureAccessibilityService.kt`: cursor overlay + tap/swipe/global actions
- `MainActivity.kt`: setup screen, gesture recorder UI

## Limits

- Camera background me tabhi chalta hai jab foreground service (notification) chal rahi ho. Koi aur app camera use kare to tracking ruk sakti hai.
- Banking apps / secure screens accessibility taps ko block kar sakti hain.
- Battery: camera + ML continuous chalta hai, to battery zyada khayega. Use na ho to Pause ya Stop kar do.
